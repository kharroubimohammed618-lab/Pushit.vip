import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as crypto from 'crypto';
import * as https from 'https';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

// Polyfilled safeFetch to support any Node version (including Node 16/18/20)
function safeFetch(url: string, options: any = {}): Promise<{ ok: boolean; status: number; text: () => Promise<string>; json: () => Promise<any> }> {
  if (typeof globalThis.fetch === 'function') {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    return (globalThis as any).fetch(url, { ...options, signal: ctrl.signal }).finally(() => clearTimeout(timer));
  }

  return new Promise((resolve, reject) => {
    try {
      const parsedUrl = new URL(url);
      const reqOptions: https.RequestOptions = {
        hostname: parsedUrl.hostname,
        path: parsedUrl.pathname + parsedUrl.search,
        method: options.method || 'GET',
        headers: options.headers || {},
      };

      const req = https.request(reqOptions, (res) => {
        const chunks: any[] = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          const body = Buffer.concat(chunks).toString();
          resolve({
            ok: (res.statusCode || 200) >= 200 && (res.statusCode || 200) < 300,
            status: res.statusCode || 200,
            text: async () => body,
            json: async () => {
              try {
                return JSON.parse(body);
              } catch (e) {
                return {};
              }
            },
          });
        });
      });

      req.on('error', (err) => {
        reject(err);
      });

      if (options.body) {
        req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
      }
      req.end();
    } catch (e) {
      reject(e);
    }
  });
}

// Must match src/lib/firebase.ts -> getFunctions(app, 'europe-west1').
// (Before this fix the server deployed to us-central1, so every callable from the app silently failed.)
const REGION = 'europe-west1';

admin.initializeApp();
const db = getFirestore('ai-studio-pushit-85848e4f-fa77-453b-9f02-aacf84b571c5');

// PUSHIT Credits Economy Constants
const TASK_REWARD = 20;
const FIRST_TASK_BONUS = 40;

// ---- Economy constants (single place to tune the business model) ----
// MUST match USD_PER_CREDIT in src/utils/currencyHelper.ts (what creators see and what a payout is worth).
const PAYOUT_USD_PER_CREDIT = 0.10;
// Percentage of every payout kept by the platform (0 = none). Disclose it in the Terms before using it.
const WITHDRAWAL_FEE_PERCENT = 0;
// A creator who joined a campaign but never submitted proof frees the slot after this delay.
const COMMITMENT_EXPIRY_MS = 72 * 3600 * 1000;
const round2 = (n: number) => Math.round(n * 100) / 100;
// New accounts cannot cash out immediately (basic fraud control; set to 0 to disable).
const MIN_ACCOUNT_AGE_DAYS_FOR_WITHDRAWAL = 3;

/** Platform bookkeeping (server-only collection): revenue, payouts, fees and reversals in USD. */
const platformLedgerEntry = (type: string, id: string, fields: Record<string, any>) => ({
  ref: db.doc(`platformLedger/${type}_${id}`),
  data: { type, id: `${type}_${id}`, createdAt: Date.now(), ...fields },
});

// Admin identity is decided ONLY by (a) the `admin` custom claim on the Firebase Auth token,
// or (b) a VERIFIED email listed in the ADMIN_EMAILS environment variable (comma separated).
// Nothing stored in Firestore (which clients could write) can grant admin rights.
const ADMIN_EMAILS: string[] = (process.env.ADMIN_EMAILS || 'mohammedkharroubi1998@gmail.com,z2u1seller@gmail.com,kharroubimohammed618@gmail.com')
  .split(',')
  .map((e) => e.trim().toLowerCase())
  .filter(Boolean);

const checkIsAdmin = async (uid: string, _email?: string): Promise<boolean> => {
  try {
    const rec = await admin.auth().getUser(uid);
    if (rec.customClaims && (rec.customClaims as any).admin === true) return true;
    if (rec.email && rec.emailVerified && ADMIN_EMAILS.includes(rec.email.toLowerCase())) return true;
  } catch (e) {
    functions.logger.error('[checkIsAdmin] auth lookup failed', e);
  }
  return false;
};

const assertNotBanned = async (uid: string) => {
  const snap = await db.doc(`usersPrivate/${uid}`).get();
  if (snap.exists && snap.data()?.isBanned === true) {
    throw new functions.https.HttpsError('permission-denied', 'This account is suspended.');
  }
};

/**
 * Canonical balance split. `karma` is the displayed total; paid = purchased credits, reward = earned credits.
 * Self-heals legacy documents where the three fields drifted apart.
 */
const getPools = (u: any): { paid: number; reward: number; total: number } => {
  const paidRaw = Number(u?.karmaPaid);
  const rewardRaw = Number(u?.karmaReward);
  const total = Math.max(
    0,
    u?.karma !== undefined && u?.karma !== null
      ? Number(u.karma) || 0
      : (Number.isFinite(paidRaw) ? paidRaw : 0) + (Number.isFinite(rewardRaw) ? rewardRaw : 0)
  );
  const paid = Math.min(total, Math.max(0, u?.karmaPaid !== undefined && Number.isFinite(paidRaw) ? paidRaw : total));
  return { paid, reward: total - paid, total };
};

/**
 * Single source of truth for "how many credits does one verified result pay".
 * Decided ONLY from campaign fields controlled by the server (never from the worker's commitment,
 * never from the campaign title).
 */
const defaultRewardForType = (promotionType: any, campaignType: any): number => {
  const t = `${String(promotionType || '')} ${String(campaignType || '')}`.toLowerCase();
  if (t.includes('ugc_clipping')) return 60;
  if (t.includes('ugc')) return 40;
  if (t.includes('clipping')) return 20;
  if (t.includes('boost')) return 10;
  return 20;
};
const rewardPerResult = (p: any): number => {
  if (p?.isOfficialPromoTask === true) return 60;
  const stored = Math.floor(Number(p?.costPerResultKarma));
  if (Number.isFinite(stored) && stored > 0) return stored;
  return defaultRewardForType(p?.promotionType, p?.campaignType);
};

const requireAuth = (context: functions.https.CallableContext): string => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'You must be signed in.');
  }
  return context.auth.uid;
};

const DOC_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
/** Client-supplied ids end up inside Firestore paths: only plain ids are accepted (no '/' or '..'). */
const assertDocId = (v: any, field: string): string => {
  if (typeof v !== 'string' || !DOC_ID_RE.test(v)) {
    throw new functions.https.HttpsError('invalid-argument', `Invalid ${field}.`);
  }
  return v;
};

const toSafeInt = (v: any, min: number, max: number, field: string): number => {
  const n = Number(v);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) {
    throw new functions.https.HttpsError('invalid-argument', `Invalid ${field}.`);
  }
  return n;
};

/**
 * 1. SERVER-AUTHORITATIVE TASK REWARD & FIRST-PUSH BONUS
 * Callable Cloud Function: awardTaskReward
 * - Accurately calculates task reward based on campaign type (60 for Official/Pushit, 40 for UGC, 20 for Clipping)
 * - Safe transaction with idempotency and audit ledger entries
 */
export const awardTaskReward = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      'unauthenticated',
      'The caller must be authenticated to approve tasks.'
    );
  }

  const commitmentId = assertDocId(data?.commitmentId || data?.taskId, 'commitmentId');
  if (!commitmentId || typeof commitmentId !== 'string') {
    throw new functions.https.HttpsError(
      'invalid-argument',
      'Missing or invalid commitmentId/taskId.'
    );
  }

  const callerUid = context.auth.uid;
  const callerEmail = context.auth.token.email;
  const isCallerAdmin = await checkIsAdmin(callerUid, callerEmail);

  const commRef = db.doc(`commitments/${commitmentId}`);
  const now = Date.now();

  return await db.runTransaction(async (transaction) => {
    try {
      // 1. Fetch Commitment Document
      const commSnap = await transaction.get(commRef);
      if (!commSnap.exists) {
        throw new functions.https.HttpsError('not-found', 'Commitment record not found.');
      }
      const commData = commSnap.data()!;

      // 2. Self-Approval Security Boundary
      if (commData.userId === callerUid && !isCallerAdmin) {
        throw new functions.https.HttpsError(
          'permission-denied',
          'Security Violation: Users are strictly forbidden from approving their own tasks.'
        );
      }

      // 3. Project Owner / Admin Verification
      const projectRef = db.doc(`projects/${commData.projectId}`);
      const projSnap = await transaction.get(projectRef);
      if (!projSnap.exists) {
        throw new functions.https.HttpsError('not-found', 'Associated project not found.');
      }
      const projData = projSnap.data()!;

      if (projData.ownerId !== callerUid && !isCallerAdmin) {
        throw new functions.https.HttpsError(
          'permission-denied',
          'Only the verified project creator or an administrator can approve this task.'
        );
      }

      // 4. Idempotency Check
      if (commData.proofStatus === 'confirmed') {
        return { success: true, alreadyProcessed: true };
      }
      if (projData.status === 'deleted' || projData.status === 'refunded') {
        throw new functions.https.HttpsError('failed-precondition', 'This campaign was deleted.');
      }
      if (commData.status === 'expired' || commData.proofStatus === 'expired') {
        throw new functions.https.HttpsError('failed-precondition', 'This commitment expired before proof was submitted.');
      }

      // 5. Worker Verification
      const workerPrivRef = db.doc(`usersPrivate/${commData.userId}`);
      const workerPrivSnap = await transaction.get(workerPrivRef);
      if (!workerPrivSnap.exists) {
        throw new functions.https.HttpsError('not-found', 'Worker user account data not found.');
      }
      const workerPrivData = workerPrivSnap.data()!;
      const workerPubRef = db.doc(`users/${commData.userId}`);

      // Reward is derived from the campaign only (see rewardPerResult)
      const taskReward = rewardPerResult(projData);

      if (workerPrivData.isBanned === true) {
        throw new functions.https.HttpsError('failed-precondition', 'The worker account is suspended.');
      }
      // BUDGET GUARD: a campaign can never pay out more than the advertiser funded.
      if (projData.isOfficialPromoTask !== true && typeof projData.budgetKarma === 'number') {
        if (Number(projData.spentKarma || 0) + taskReward > projData.budgetKarma) {
          throw new functions.https.HttpsError('failed-precondition', 'Campaign budget exhausted.');
        }
      }

      const workerPools = getPools(workerPrivData);
      const currentKarma = workerPools.total;
      const currentPaid = workerPools.paid;
      const currentReward = workerPools.reward;
      const hasClaimedFirstBonus = Boolean(workerPrivData.firstTaskBonusClaimed);
      const isPhoneVerified = Boolean(workerPrivData.phoneVerified) && Boolean(workerPrivData.phoneHash);
      const canReceiveBonus = !hasClaimedFirstBonus && isPhoneVerified;
      const firstBonus = canReceiveBonus ? FIRST_TASK_BONUS : 0;
      const totalRewardAdded = taskReward + firstBonus;
      // The welcome bonus is platform-funded marketing credit: usable to launch campaigns but NOT withdrawable,
      // otherwise fake accounts with disposable phone numbers could cash out free money.
      const newReward = currentReward + taskReward;
      const newPaid = currentPaid + firstBonus;
      const newBalance = newPaid + newReward;
      const newLifetimeEarned = Number(workerPrivData.lifetimeEarned ?? currentKarma) + totalRewardAdded;

      // 6. Write Immutable TASK_REWARD Ledger Entry
      const taskTxRef = db.collection('karmaTransactions').doc(`tx_task_${commitmentId}`);
      transaction.set(taskTxRef, {
        id: taskTxRef.id,
        userId: commData.userId,
        amount: taskReward,
        type: 'TASK_REWARD',
        description: `Completed approved task: ${projData.title || commData.projectTitle || commData.projectId} (+${taskReward} Credits)`,
        referenceId: commitmentId,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: callerUid,
        metadata: {
          commitmentId,
          projectId: commData.projectId,
          rewardAmount: taskReward,
          reviewerId: callerUid,
          reviewerRole: isCallerAdmin ? 'admin' : 'project_owner',
        },
      });

      // 7. Write Immutable FIRST_TASK_BONUS Ledger Entry (if eligible with verified phone)
      if (firstBonus > 0) {
        const bonusTxRef = db.collection('karmaTransactions').doc(`tx_bonus_${commitmentId}`);
        transaction.set(bonusTxRef, {
          id: bonusTxRef.id,
          userId: commData.userId,
          amount: firstBonus,
          type: 'FIRST_TASK_BONUS',
          description: `First Push welcome bonus (+${firstBonus} Credits)`,
          referenceId: commitmentId,
          balanceAfter: newBalance,
          createdAt: now + 1,
          createdBy: 'system',
          metadata: {
            commitmentId,
            projectId: commData.projectId,
            firstBonus,
            phoneHash: workerPrivData.phoneHash,
          },
        });

        if (workerPrivData.phoneHash) {
          const phoneRef = db.doc(`phones/${workerPrivData.phoneHash}`);
          transaction.set(
            phoneRef,
            {
              phoneHash: workerPrivData.phoneHash,
              claimedByUid: commData.userId,
              claimedAt: now,
              bonusClaimed: true,
            },
            { merge: true }
          );
        }
      }

      // 8. Update Worker Account Document
      transaction.update(workerPrivRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        balance: newBalance,
        lifetimeEarned: newLifetimeEarned,
        firstTaskBonusClaimed: hasClaimedFirstBonus || (firstBonus > 0),
        submissionSlots: (workerPrivData.submissionSlots || 0) + 2,
        updatedAt: now,
      });

      // Update Worker Public Profile Document
      transaction.update(workerPubRef, {
        confirmedPushes: FieldValue.increment(1),
        pushesGiven: FieldValue.increment(1),
        updatedAt: now,
      });

      // 9. Update Commitment Status
      transaction.update(commRef, {
        proofStatus: 'confirmed',
        status: 'completed',
        adminApproved: isCallerAdmin,
        rewardAmount: taskReward,
        reviewedBy: callerUid,
        reviewedAt: now,
        confirmedAt: now,
        proofConfirmedAt: now,
        updatedAt: now,
      });

      // 10. Update Project Engagement Counters and Status
      transaction.update(projectRef, {
        confirmedCount: FieldValue.increment(1),
        completedCount: FieldValue.increment(1),
        // pushCount is NOT incremented here: the slot was already counted when the creator joined (commitPush).
        // Counting it twice closed campaigns at half capacity while the paid budget stayed unused.
        spentKarma: FieldValue.increment(taskReward),
        updatedAt: now,
      });

      return {
        success: true,
        newBalance,
        taskReward,
        firstBonus,
        totalAwarded: totalRewardAdded,
        isFirstBonus: firstBonus > 0,
      };
    } catch (err: any) {
      functions.logger.error('[awardTaskReward] Transaction failed:', err);
      throw err;
    }
  });
});

/**
 * 2. SERVER-AUTHORITATIVE PROMOTE PUSHIT VIDEO BOUNTY APPROVAL
 * Callable Cloud Function: approvePushitPromotionBounty
 * - Only verified Admins can invoke
 * - Submitter cannot self-approve
 * - Awards +60 KARMA, writes auditable TASK_REWARD ledger entry
 */
export const approvePushitPromotionBounty = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'Admin authentication required.');
  }

  const submissionId = assertDocId(data?.submissionId, 'submissionId');
  if (!submissionId) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing submissionId.');
  }

  const callerUid = context.auth.uid;
  const isCallerAdmin = await checkIsAdmin(callerUid, context.auth.token.email);
  if (!isCallerAdmin) {
    throw new functions.https.HttpsError('permission-denied', 'Admin privileges required.');
  }

  const subRef = db.doc(`promotePushitSubmissions/${submissionId}`);
  const now = Date.now();

  return await db.runTransaction(async (transaction) => {
    const subSnap = await transaction.get(subRef);
    if (!subSnap.exists) {
      throw new functions.https.HttpsError('not-found', 'Submission record not found.');
    }
    const subData = subSnap.data()!;

    if (subData.userId === callerUid) {
      throw new functions.https.HttpsError(
        'permission-denied',
        'Security Violation: Admins cannot approve their own UGC submissions.'
      );
    }

    if (subData.status === 'approved') {
      return { success: true, alreadyProcessed: true };
    }

    const workerPrivRef = db.doc(`usersPrivate/${subData.userId}`);
    const workerPrivSnap = await transaction.get(workerPrivRef);
    if (!workerPrivSnap.exists) {
      throw new functions.https.HttpsError('not-found', 'Creator account data not found.');
    }
    const workerPrivData = workerPrivSnap.data()!;
    const reward = 60;
    const pools = getPools(workerPrivData);
    const newReward = pools.reward + reward;
    const newBalance = pools.paid + newReward;

    // 1. Update submission status
    transaction.update(subRef, {
      status: 'approved',
      reviewedAt: now,
      reviewedBy: callerUid,
    });

    // 2. Update creator private balance (all three balance fields stay consistent)
    transaction.update(workerPrivRef, {
      karmaPaid: pools.paid,
      karmaReward: newReward,
      karma: newBalance,
      lifetimeEarned: Number(workerPrivData.lifetimeEarned ?? pools.total) + reward,
      submissionSlots: FieldValue.increment(3),
      updatedAt: now,
    });

    // 3. Write immutable ledger entry
    const txRef = db.collection('karmaTransactions').doc(`tx_ugc_${submissionId}`);
    transaction.set(txRef, {
      id: txRef.id,
      userId: subData.userId,
      amount: reward,
      type: 'TASK_REWARD',
      description: `PUSHIT Influencer Bounty: ${subData.socialPlatform || 'Video'} promotion`,
      referenceId: submissionId,
      balanceAfter: newBalance,
      createdAt: now,
      createdBy: callerUid,
      metadata: {
        submissionId,
        videoUrl: subData.videoUrl,
        socialPlatform: subData.socialPlatform,
      },
    });

    return { success: true, newBalance };
  });
});

/**
 * 3. REAL FIREBASE PHONE AUTHENTICATION CLAIM
 * Callable Cloud Function: verifyPhoneAuth
 * CRITICAL SECURITY REQUIREMENT:
 * - NEVER accepts a client-supplied phoneNumber parameter!
 * - MUST inspect context.auth.token.phone_number verified by Firebase Authentication OTP.
 * - Rejects any caller without a verified phone_number on their auth token.
 */
export const verifyPhoneAuth = functions.region(REGION).https.onCall(async (_data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated.');
  }

  // Inspect verified phone identity directly from Firebase Auth Token!
  const verifiedPhoneNumber = context.auth.token.phone_number;
  if (!verifiedPhoneNumber || typeof verifiedPhoneNumber !== 'string' || verifiedPhoneNumber.trim() === '') {
    throw new functions.https.HttpsError(
      'failed-precondition',
      'SECURITY REJECTION: No verified Firebase Phone Authentication token found on account. You must complete real SMS OTP Phone Auth first.'
    );
  }

  const normalized = verifiedPhoneNumber.replace(/[^\d+]/g, '').trim();
  const phoneHash = crypto.createHash('sha256').update(normalized).digest('hex');
  const phoneRef = db.doc(`phones/${phoneHash}`);
  const userPrivRef = db.doc(`usersPrivate/${context.auth.uid}`);
  const now = Date.now();

  return await db.runTransaction(async (transaction) => {
    const phoneSnap = await transaction.get(phoneRef);
    if (phoneSnap.exists && phoneSnap.data()?.claimedByUid !== context.auth!.uid) {
      throw new functions.https.HttpsError(
        'already-exists',
        'SECURITY REJECTION: This verified phone number has already been registered on another PUSHIT account.'
      );
    }

    transaction.set(
      phoneRef,
      {
        phoneHash,
        claimedByUid: context.auth!.uid,
        claimedAt: now,
        bonusClaimed: phoneSnap.exists ? Boolean(phoneSnap.data()?.bonusClaimed) : false,
      },
      { merge: true }
    );

    transaction.update(userPrivRef, {
      phoneVerified: true,
      phoneHash,
      updatedAt: now,
    });

    return { success: true, phoneHash };
  });
});

/**
 * 4. SERVER-AUTHORITATIVE PUSH COMMITMENT & COUNTER INCREMENT
 * Callable Cloud Function: commitPush
 * - Validates authentication
 * - Validates project existence
 * - Creates commitment record and atomically increments pushCount on the project
 */
export const commitPush = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated to commit to a push.');
  }

  const {
    projectId,
    projectTitle,
    userName,
    userAvatar,
    actionType,
    timeframe,
    notes,
    requirementId,
    selectedActionType,
    selectedPlatform,
  } = data;

  assertDocId(projectId, 'projectId');

  const callerUid = context.auth.uid;
  await assertNotBanned(callerUid);
  // Anti-abuse: at most 50 unfinished commitments per user
  const openCommitments = await db.collection('commitments')
    .where('userId', '==', callerUid).where('status', '==', 'committed').limit(50).get();
  if (openCommitments.size >= 50) {
    throw new functions.https.HttpsError('resource-exhausted', 'Too many unfinished tasks. Submit proof for some before joining more.');
  }
  const projectRef = db.doc(`projects/${projectId}`);
  const now = Date.now();

  const commRef = db.collection('commitments').doc();
  const commitmentData = {
    id: commRef.id,
    projectId,
    projectTitle: String(projectTitle || 'Project').slice(0, 200),
    userId: callerUid,
    userName: String(userName || 'Maker').slice(0, 100),
    userAvatar: /^https?:\/\//i.test(String(userAvatar || '')) ? String(userAvatar).slice(0, 500) : '',
    actionType: String(actionType || 'Reel').slice(0, 50),
    requirementId: String(requirementId || '').slice(0, 100),
    selectedActionType: String(selectedActionType || '').slice(0, 100),
    selectedPlatform: String(selectedPlatform || '').slice(0, 50),
    timeframe: String(timeframe || 'Today').slice(0, 50),
    notes: String(notes || '').slice(0, 1000),
    status: 'committed',
    proofStatus: 'pending',
    adminApproved: false,
    createdAt: now,
  };

  return await db.runTransaction(async (transaction) => {
    const projSnap = await transaction.get(projectRef);
    if (!projSnap.exists) {
      throw new functions.https.HttpsError('not-found', 'Project not found.');
    }

    const projData = projSnap.data()!;

    // Free slots held by creators who joined but never submitted proof within the expiry window,
    // so a campaign is never blocked by abandoned commitments.
    const openSnap = await transaction.get(
      db.collection('commitments').where('projectId', '==', projectId).where('status', '==', 'committed').limit(50)
    );
    const staleDocs = openSnap.docs.filter((d) => {
      const c = d.data();
      return c.proofStatus === 'pending' && !c.proofUrl && now - Number(c.createdAt || 0) > COMMITMENT_EXPIRY_MS;
    });
    const targetGoalForSlots = Number(projData.targetGoal || 10);
    const effectivePushes = Math.max(0, Number(projData.pushCount || 0) - staleDocs.length);
    const reopenable =
      projData.status === 'completed' && projData.completedBy === 'goal' &&
      effectivePushes < targetGoalForSlots && Number(projData.confirmedCount || 0) < targetGoalForSlots;

    if (projData.status && projData.status !== 'active' && !reopenable) {
      throw new functions.https.HttpsError('failed-precondition', 'This campaign is paused or completed.');
    }
    if (projData.ownerId === callerUid) {
      throw new functions.https.HttpsError('failed-precondition', 'You cannot push your own campaign.');
    }
    // Anti-farming: one active commitment per user / campaign / requirement
    const mine = await transaction.get(
      db.collection('commitments').where('userId', '==', callerUid).where('projectId', '==', projectId)
    );
    const duplicate = mine.docs.some((d) => {
      const c = d.data();
      return (c.requirementId || '') === (requirementId || '') && c.proofStatus !== 'rejected';
    });
    if (duplicate) {
      throw new functions.https.HttpsError('already-exists', 'You already joined this campaign.');
    }
    const currentPushes = effectivePushes;
    const targetGoal = targetGoalForSlots;
    if (currentPushes >= targetGoal) {
      throw new functions.https.HttpsError('failed-precondition', 'This campaign has already reached its push target goal.');
    }

    staleDocs.forEach((d) => transaction.update(d.ref, { status: 'expired', proofStatus: 'expired', expiredAt: now }));

    // Set new commitment record
    transaction.set(commRef, commitmentData);

    const isGoalReached = (currentPushes + 1) >= targetGoal;
    transaction.update(projectRef, {
      pushCount: currentPushes + 1,
      status: isGoalReached ? 'completed' : 'active',
      completedBy: isGoalReached ? 'goal' : FieldValue.delete(),
      updatedAt: now,
    });

    return { success: true, commitmentId: commRef.id };
  });
});

/**
 * 4.1 SERVER-AUTHORITATIVE CAMPAIGN DELETION & REFUND
 * Callable Cloud Function: deleteCampaignWithRefund
 * - Verifies ownership or admin
 * - Atomically calculates and refunds unspent karma (budgetKarma - spentKarma)
 * - Writes immutable CAMPAIGN_DELETE_REFUND audit ledger entry
 * - Deletes project document atomically
 */
export const deleteCampaignWithRefund = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated.');
  }

  const projectId = assertDocId(data?.projectId, 'projectId');
  if (!projectId || typeof projectId !== 'string') {
    throw new functions.https.HttpsError('invalid-argument', 'Missing or invalid projectId.');
  }

  const callerUid = context.auth.uid;
  const callerEmail = context.auth.token.email;
  const isCallerAdmin = await checkIsAdmin(callerUid, callerEmail);
  const now = Date.now();

  const projectRef = db.doc(`projects/${projectId}`);

  return await db.runTransaction(async (transaction) => {
    const projSnap = await transaction.get(projectRef);
    if (!projSnap.exists) {
      return { success: true, refundedKarma: 0, refundedPaid: 0, refundedReward: 0 };
    }

    const projData = projSnap.data()!;
    if (projData.ownerId !== callerUid && !isCallerAdmin) {
      throw new functions.https.HttpsError('permission-denied', 'You do not have permission to delete this campaign.');
    }

    // Guard against double refunds: if already refunded or marked deleted, issue no refund
    if (projData.status === 'refunded' || projData.status === 'deleted' || Boolean(projData.refundedAt)) {
      transaction.delete(projectRef);
      return {
        success: true,
        alreadyRefunded: true,
        refundedKarma: 0,
        refundedPaid: 0,
        refundedReward: 0,
      };
    }

    const targetUserId = projData.ownerId;
    const userPrivRef = db.doc(`usersPrivate/${targetUserId}`);
    const userPrivSnap = await transaction.get(userPrivRef);

    // Fairness: creators who already delivered must be paid or rejected before the budget is withdrawn.
    if (!isCallerAdmin) {
      const awaiting = await transaction.get(
        db.collection('commitments')
          .where('projectId', '==', projectId)
          .where('proofStatus', '==', 'pending')
          .where('status', '==', 'completed')
          .limit(1)
      );
      if (!awaiting.empty) {
        throw new functions.https.HttpsError('failed-precondition', 'PENDING_SUBMISSIONS: review the submitted proofs (approve or reject) before deleting this campaign.');
      }
    }

    const rewardPerPush = rewardPerResult(projData);

    const allocatedBudget = typeof projData.budgetKarma === 'number' && projData.budgetKarma > 0
      ? projData.budgetKarma
      : Number(projData.targetGoal || 10) * rewardPerPush;

    // Source of truth: compute verified task payouts from confirmed commitments
    const commsQuery = db.collection('commitments')
      .where('projectId', '==', projectId)
      .where('proofStatus', '==', 'confirmed');
    const commsSnap = await transaction.get(commsQuery);

    let verifiedConfirmedSpend = 0;
    commsSnap.forEach((docSnap) => {
      const cData = docSnap.data();
      verifiedConfirmedSpend += Number(cData.rewardAmount || rewardPerPush);
    });

    const recordedSpentKarma = typeof projData.spentKarma === 'number' ? projData.spentKarma : 0;
    const actualSpentKarma = Math.max(verifiedConfirmedSpend, recordedSpentKarma);
    const unspentRefund = Math.max(0, allocatedBudget - actualSpentKarma);

    const hasDualTokens = typeof projData.spentPaidKAR === 'number' || typeof projData.spentRewardKAR === 'number';
    const spentPaid = Number(projData.spentPaidKAR ?? 0);
    const spentReward = Number(projData.spentRewardKAR ?? 0);

    let refundPaid = 0;
    let refundReward = 0;

    if (allocatedBudget <= 0 || unspentRefund <= 0) {
      refundPaid = 0;
      refundReward = 0;
    } else if (hasDualTokens) {
      // Calculate unspent ratio strictly bounded between 0 and 1
      const unspentRatio = Math.min(1, unspentRefund / allocatedBudget);
      refundPaid = Math.floor(spentPaid * unspentRatio);
      refundReward = Math.floor(spentReward * unspentRatio);
    } else {
      refundPaid = unspentRefund;
      refundReward = 0;
    }

    if ((refundPaid > 0 || refundReward > 0) && userPrivSnap.exists) {
      const uData = userPrivSnap.data()!;
      const { paid: curPaid, reward: curReward } = getPools(uData);
      const newPaid = curPaid + refundPaid;
      const newReward = curReward + refundReward;
      const newBalance = newPaid + newReward;
      const totalRefundKarma = refundPaid + refundReward;

      const txRef = db.collection('karmaTransactions').doc(`tx_del_refund_${projectId}_${now}`);
      transaction.set(txRef, {
        id: txRef.id,
        userId: targetUserId,
        amount: totalRefundKarma,
        type: 'CAMPAIGN_DELETE_REFUND',
        description: `Deleted campaign and refunded unspent budget (+${refundPaid} KAR, +${refundReward} rKAR): ${projData.title || projectId}`,
        referenceId: projectId,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: callerUid,
        metadata: {
          projectId,
          allocatedBudget,
          actualSpentKarma,
          verifiedConfirmedSpend,
          unspentRefund,
          refundPaid,
          refundReward,
        },
      });

      transaction.update(userPrivRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        submissionSlots: Math.max(0, Math.floor(newBalance / 20)),
        updatedAt: now,
      });
    }

    transaction.delete(projectRef);
    return {
      success: true,
      refundedPaid: refundPaid,
      refundedReward: refundReward,
      refundedKarma: refundPaid + Math.floor(refundReward / 3),
    };
  });
});

/**
 * 5. SERVER-SIDE WHOP CREDENTIALS HELPER
 */
async function getWhopConfig() {
  let privData: any = {};
  let pubData: any = {};

  try {
    const privSnap = await db.doc('settings/payment_gateways_private').get();
    privData = privSnap.exists ? privSnap.data()?.whop || {} : {};
  } catch (e: any) {
    functions.logger.warn('[getWhopConfig] Could not read private payment settings:', e?.message);
  }

  try {
    const pubSnap = await db.doc('settings/payment_gateways').get();
    pubData = pubSnap.exists ? pubSnap.data()?.whop || {} : {};
  } catch (e: any) {
    functions.logger.warn('[getWhopConfig] Could not read public payment settings:', e?.message);
  }

  return {
    enabled: Boolean(pubData.enabled ?? privData.enabled ?? true),
    apiKey: String(privData.apiKey || pubData.apiKey || '').trim(),
    webhookSecret: String(privData.webhookSecret || pubData.webhookSecret || '').trim(),
    defaultPlanId: String(pubData.planId || pubData.defaultPlanId || pubData.productId || privData.planId || privData.defaultPlanId || privData.productId || 'plan_vmaDAQ1LrufDU').trim(),
    checkoutUrl: String(pubData.checkoutUrl || '').trim(),
  };
}

/**
 * 6. ADMIN-ONLY TEST WHOP CONNECTION
 * Callable Cloud Function: testWhopConnection
 * - Server-side API key & Plan ID verification
 * - Rejects malformed Plan IDs or invalid API keys
 */
export const testWhopConnection = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'Admin authentication required.');
  }

  const callerUid = context.auth.uid;
  const isAdmin = await checkIsAdmin(callerUid, context.auth.token.email);
  if (!isAdmin) {
    throw new functions.https.HttpsError('permission-denied', 'Only platform administrators can test Whop connection.');
  }

  const whopConfig = await getWhopConfig();
  const apiKey = (data?.apiKey || whopConfig.apiKey).trim();
  const planId = (data?.planId || whopConfig.defaultPlanId).trim();

  if (!apiKey) {
    return {
      success: false,
      connected: false,
      code: 'WHOP_AUTH_INVALID',
      message: 'Whop API key is missing. Please enter your Whop API Key in Admin Dashboard settings.',
    };
  }

  if (planId && (planId.startsWith('http://') || planId.startsWith('https://') || planId.includes('/'))) {
    return {
      success: false,
      connected: false,
      planValid: false,
      code: 'WHOP_CONFIGURATION_INVALID',
      message: 'Invalid Whop Plan ID format. A Whop Plan ID must start with plan_ (e.g. plan_x1y2z3), not a full URL.',
    };
  }

  try {
    // 1. Validate Whop API Key via Whop API
    const meRes = await safeFetch('https://api.whop.com/api/v5/me', {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (meRes.status === 401 || meRes.status === 403) {
      return {
        success: false,
        connected: false,
        code: 'WHOP_AUTH_INVALID',
        message: 'Whop API authentication failed. Please verify your Whop API Key.',
      };
    }

    // 2. Validate Whop Plan ID if provided
    let planValid = false;
    let planInfo = '';

    if (planId) {
      if (!planId.startsWith('plan_')) {
        return {
          success: false,
          connected: true,
          planValid: false,
          code: 'WHOP_CONFIGURATION_INVALID',
          message: 'Invalid Whop Plan ID format. Must start with plan_ (e.g., plan_xxxxxxxxxxxxx).',
        };
      }

      const planRes = await safeFetch(`https://api.whop.com/api/v5/plans/${planId}`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (planRes.ok) {
        const planData = await planRes.json();
        planValid = true;
        planInfo = ` (Plan: ${planData.name || planId}, Price: $${((planData.initial_price || 0) / 100).toFixed(2)} ${planData.currency || 'USD'})`;
      } else if (planRes.status === 404) {
        return {
          success: false,
          connected: true,
          planValid: false,
          code: 'WHOP_PLAN_NOT_FOUND',
          message: `Whop API connected, but Plan ID (${planId}) was not found on your Whop account (HTTP 404).`,
        };
      } else if (planRes.status === 403 || planRes.status === 401) {
        return {
          success: false,
          connected: true,
          planValid: false,
          code: 'WHOP_PERMISSION_DENIED',
          message: `Whop API connected, but permissions were denied to access Plan ID (${planId}) (HTTP ${planRes.status}).`,
        };
      } else {
        return {
          success: false,
          connected: true,
          planValid: false,
          code: 'WHOP_PLAN_INACTIVE',
          message: `Whop API connected, but Plan ID (${planId}) is inactive or unavailable (HTTP ${planRes.status}).`,
        };
      }
    }

    return {
      success: true,
      connected: true,
      planValid: Boolean(planValid || !planId),
      code: 'WHOP_CONNECTION_OK',
      message: `✓ Whop API connected successfully!${planInfo}`,
    };
  } catch (err: any) {
    return {
      success: false,
      connected: false,
      code: 'WHOP_CONNECTION_ERROR',
      message: `Whop API connection error: ${err?.message || String(err)}`,
    };
  }
});

/**
 * Shared Authoritative Server-Side Fulfillment Transaction Function
 * - Atomic usersPrivate updates
 * - Immutable karmaTransactions ledger generation
 * - Deterministic tx_purchase_{orderId} document IDs
 * - Idempotency-guaranteed (blocks duplicate credits)
 */
// Karma granted for each Whop plan. This table (or the admin-managed coin_packages
// collection) is the ONLY source of truth for how many credits a payment is worth.
// Anything written by a client (order.totalKarma, customKarma, ...) is ignored.
const WHOP_PLAN_KARMA_MAP: Record<string, number> = {
  plan_XobJA5AxLRNiE: 20,    // $2.99 USD  (Starter, disabled for sale)
  plan_vmaDAQ1LrufDU: 55,    // $7.99 USD  (50 + 5 bonus)
  plan_Xm9RoYeEYAvKd: 105,   // $14.99 USD (100 + 5 bonus)
  plan_OAprN0t0rpn5Q: 215,   // $29.99 USD (200 + 15 bonus)
  plan_1wP4ttXclcHv0: 510,   // $69.99 USD (450 + 60 bonus)
};

type PaidInfo = { planId?: string; adminOverride?: boolean };

const extractPaidPlanId = (p: any): string => {
  const candidates = [
    p?.plan_id, p?.planId, p?.plan?.id, p?.plan?.plan_id,
    p?.membership?.plan_id, p?.membership?.plan?.id, p?.checkout?.plan_id,
  ];
  for (const v of candidates) {
    if (typeof v === 'string' && v.startsWith('plan_')) return v;
  }
  return '';
};

/**
 * A refunded or disputed payment must take the credits back. Credits already spent cannot be recovered,
 * so the shortfall is recorded as `chargebackDebt` and the account is put on payout hold.
 */
async function reversePurchaseOrder(orderId: string, reason: string): Promise<{ reversed: boolean; debt: number }> {
  const orderRef = db.doc(`purchases/${orderId}`);
  const now = Date.now();
  return await db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(orderRef);
    if (!orderSnap.exists) return { reversed: false, debt: 0 };
    const order = orderSnap.data()!;
    if (order.status === 'refunded') return { reversed: true, debt: 0 };
    if (order.status !== 'completed') {
      tx.update(orderRef, { status: 'cancelled', reversalReason: reason, updatedAt: now });
      return { reversed: false, debt: 0 };
    }
    const privRef = db.doc(`usersPrivate/${order.userId}`);
    const privSnap = await tx.get(privRef);
    const credits = Number(order.totalKarma || 0);
    let debt = credits;
    if (privSnap.exists) {
      const u = privSnap.data()!;
      const pools = getPools(u);
      let take = credits;
      const fromPaid = Math.min(pools.paid, take);
      take -= fromPaid;
      const fromReward = Math.min(pools.reward, take);
      take -= fromReward;
      debt = take;
      const newPaid = pools.paid - fromPaid;
      const newReward = pools.reward - fromReward;
      const newBalance = newPaid + newReward;
      tx.update(privRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        chargebackDebt: Number(u.chargebackDebt || 0) + debt,
        payoutHold: true,
        updatedAt: now,
      });
      const ledgerRef = db.collection('karmaTransactions').doc(`tx_reversal_${orderId}`);
      tx.set(ledgerRef, {
        id: ledgerRef.id,
        userId: order.userId,
        amount: -(fromPaid + fromReward),
        type: 'PURCHASE_REVERSAL',
        description: `Payment refunded/disputed: ${credits} Credits reversed (${debt} Credits could not be recovered)`,
        referenceId: orderId,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: 'system',
        metadata: { orderId, reason, unrecoveredCredits: debt },
      });
    }
    const entry = platformLedgerEntry('REFUND', orderId, {
      userId: order.userId,
      amountUsd: -Number(order.amountUsd || 0),
      credits: -credits,
      reason,
      unrecoveredCredits: debt,
    });
    tx.set(entry.ref, entry.data);
    tx.update(orderRef, { status: 'refunded', reversalReason: reason, reversedAt: now, updatedAt: now });
    return { reversed: true, debt };
  });
}

// Built-in catalogue, used only while a package has no document in the admin-managed coin_packages collection.
const DEFAULT_PACKAGES: Record<string, { karma: number; bonus: number; price: number; plan: string }> = {
  pkg_starter: { karma: 20, bonus: 0, price: 2.99, plan: 'plan_XobJA5AxLRNiE' },
  pkg_popular: { karma: 50, bonus: 5, price: 7.99, plan: 'plan_vmaDAQ1LrufDU' },
  pkg_growth: { karma: 100, bonus: 5, price: 14.99, plan: 'plan_Xm9RoYeEYAvKd' },
  pkg_pro: { karma: 200, bonus: 15, price: 29.99, plan: 'plan_OAprN0t0rpn5Q' },
  pkg_agency: { karma: 450, bonus: 60, price: 69.99, plan: 'plan_1wP4ttXclcHv0' },
};

/**
 * Resolves a purchasable package. Throws when the package is unknown or misconfigured.
 * A package MUST carry its own Whop plan id: falling back to a default plan would let a customer
 * pay a cheap plan's price for an expensive package's credits.
 */
async function resolvePackage(packageId: string) {
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(packageId)) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid package.');
  }
  let karmaAmount = 0;
  let bonusKarma = 0;
  let amountUsd = 0;
  let planId = '';
  let packageName = '';

  let data: Record<string, any> | null = null;
  try {
    const snap = await db.doc(`coin_packages/${packageId}`).get();
    if (snap.exists) data = snap.data()!;
  } catch (e: any) {
    functions.logger.warn('[resolvePackage] coin_packages read failed, using built-in catalogue:', e?.message);
  }

  if (data) {
    karmaAmount = Number(data.karmaAmount || 0);
    bonusKarma = Number(data.bonusKarma || 0);
    amountUsd = Number(data.priceUsd || 0);
    planId = String(data.whopPlanId || '').trim();
    packageName = String(data.name || '').slice(0, 100);
    if (data.isActive === false) {
      throw new functions.https.HttpsError('failed-precondition', 'This package is not available.');
    }
    // Packages created before plan ids were stored in Firestore: reuse the built-in Whop plan ONLY when the
    // document matches that plan's credits and price exactly. Any other mismatch must be fixed by setting
    // `whopPlanId` on the document (otherwise a customer could pay a cheap plan for an expensive package).
    if (!planId && DEFAULT_PACKAGES[packageId]) {
      const d = DEFAULT_PACKAGES[packageId];
      if (karmaAmount === d.karma && bonusKarma === d.bonus && Math.abs(amountUsd - d.price) < 0.005) {
        planId = d.plan;
      }
    }
  } else if (DEFAULT_PACKAGES[packageId] && packageId !== 'pkg_starter') {
    const d = DEFAULT_PACKAGES[packageId];
    karmaAmount = d.karma;
    bonusKarma = d.bonus;
    amountUsd = d.price;
    planId = d.plan;
  } else {
    throw new functions.https.HttpsError('invalid-argument', 'Unknown package.');
  }

  const totalKarma = karmaAmount + bonusKarma;
  if (!(karmaAmount > 0) || !(bonusKarma >= 0) || !(amountUsd > 0) || totalKarma > 100000 || !planId.startsWith('plan_')) {
    throw new functions.https.HttpsError('failed-precondition', 'This package is not available for purchase yet.');
  }
  return { karmaAmount, bonusKarma, totalKarma, amountUsd, planId, packageName: packageName || `${totalKarma} KAR Package` };
}

async function resolveOrderKarma(order: Record<string, any>): Promise<number | null> {
  if (order.gateway !== 'whop') return null; // paypal/manual are never auto-fulfilled
  const planId = String(order.whopPlanId || '').trim();
  if (!planId.startsWith('plan_')) return null;
  try {
    const pkg = await resolvePackage(String(order.packageId || ''));
    if (pkg.planId === planId) return pkg.totalKarma;
  } catch {
    // fall through to the legacy plan table
  }
  return WHOP_PLAN_KARMA_MAP[planId] ?? null;
}

async function fulfillPurchaseOrder(
  orderId: string,
  gatewayTransactionId: string,
  triggeredBy: string,
  paid: PaidInfo = {}
): Promise<{ fulfilled: boolean; reason?: string }> {
  const orderRef = db.doc(`purchases/${orderId}`);
  const txRef = db.collection('karmaTransactions').doc(`tx_purchase_${orderId}`);
  const now = Date.now();
  const isRealTxId = !!gatewayTransactionId && !/^WHOP_(WEB|PAY)_\d+$/.test(gatewayTransactionId);
  const claimRef = isRealTxId
    ? db.doc(`paymentClaims/${gatewayTransactionId.replace(/[\/\s]/g, '_').slice(0, 200)}`)
    : null;

  return await db.runTransaction(async (transaction) => {
    // ---- reads first ----
    const orderSnap = await transaction.get(orderRef);
    if (!orderSnap.exists) {
      throw new Error(`Purchase order ${orderId} not found.`);
    }
    const order = orderSnap.data()!;

    if (order.status === 'completed' || order.status === 'paid' || order.status === 'fulfilled') {
      return { fulfilled: true, reason: 'already_completed' };
    }
    if (order.status === 'flagged' && !paid.adminOverride) {
      return { fulfilled: false, reason: 'flagged' };
    }

    const userPrivRef = db.doc(`usersPrivate/${order.userId}`);
    const userPrivSnap = await transaction.get(userPrivRef);
    if (!userPrivSnap.exists) {
      throw new Error(`User private record for ${order.userId} not found.`);
    }
    const claimSnap = claimRef ? await transaction.get(claimRef) : null;
    const karmaToAdd = await resolveOrderKarma(order);

    // ---- verification (writes only status flags on failure) ----
    const hold = (status: string, reason: string) => {
      functions.logger.error(`[Fulfill] Order ${orderId} held as ${status}: ${reason}`);
      transaction.update(orderRef, { status, holdReason: reason, updatedAt: now });
      return { fulfilled: false, reason };
    };

    if (!karmaToAdd || karmaToAdd <= 0) return hold('needs_review', 'unknown_package_or_plan');
    if (!paid.adminOverride) {
      const expectedPlan = String(order.whopPlanId || '').trim();
      if (!paid.planId) return hold('needs_review', 'plan_not_verifiable');
      if (paid.planId !== expectedPlan) return hold('flagged', 'plan_mismatch');
      if (claimSnap && claimSnap.exists && claimSnap.data()?.orderId !== orderId) {
        return hold('flagged', 'payment_reused');
      }
    }

    const userPrivData = userPrivSnap.data()!;
    const totalKarmaToAdd = karmaToAdd;
    const { paid: currentKarmaPaid, reward: currentKarmaReward } = getPools(userPrivData);
    const newKarmaPaid = currentKarmaPaid + totalKarmaToAdd;
    const newBalance = newKarmaPaid + currentKarmaReward;
    const currentEarned = Number(userPrivData.lifetimeEarned ?? (currentKarmaPaid + currentKarmaReward));
    const newLifetimeEarned = currentEarned + totalKarmaToAdd;

    transaction.update(userPrivRef, {
      karmaPaid: newKarmaPaid,
      karmaReward: currentKarmaReward,
      karma: newBalance,
      lifetimeEarned: newLifetimeEarned,
      submissionSlots: FieldValue.increment(Math.floor(totalKarmaToAdd / 20)),
      updatedAt: now,
    });

    transaction.set(txRef, {
      id: txRef.id,
      userId: order.userId,
      amount: totalKarmaToAdd,
      type: 'RECHARGE_PURCHASE',
      description: `Whop Recharge: ${order.packageName || 'KAR Pack'} (+${totalKarmaToAdd} KAR)`,
      referenceId: orderId,
      balanceAfter: newBalance,
      createdAt: now,
      createdBy: triggeredBy,
      metadata: { orderId, gateway: 'whop', amountUsd: order.amountUsd, gatewayTransactionId },
    });

    if (claimRef) {
      transaction.set(claimRef, { orderId, userId: order.userId, createdAt: now });
    }

    const revenue = platformLedgerEntry('PURCHASE', orderId, {
      userId: order.userId,
      amountUsd: Number(order.amountUsd || 0),
      credits: totalKarmaToAdd,
      gateway: 'whop',
      gatewayTransactionId,
    });
    transaction.set(revenue.ref, revenue.data);

    transaction.update(orderRef, {
      status: 'completed',
      totalKarma: totalKarmaToAdd,
      gatewayTransactionId,
      fulfilledAt: now,
      updatedAt: now,
    });
    return { fulfilled: true };
  });
}

/**
 * 7. SERVER-SIDE WHOP CHECKOUT SESSION CREATION
 * Callable Cloud Function: createWhopCheckout
 * - Creates a pending purchase record in Firestore FIRST
 * - Server validates package, price, and Whop Plan ID
 * - Returns checkout URL with user/order metadata attached
 */
export const createWhopCheckout = functions.region(REGION).https.onCall(async (data, context) => {
  const callerUid = requireAuth(context);
  try {
    const packageId = data?.packageId;
    if (!packageId || typeof packageId !== 'string') {
      throw new functions.https.HttpsError('invalid-argument', 'Missing or invalid packageId.');
    }
    await assertNotBanned(callerUid);

    const whopConfig = await getWhopConfig();
    if (!whopConfig.apiKey || whopConfig.enabled === false) {
      throw new functions.https.HttpsError('failed-precondition', 'Card payments are not available right now.');
    }

    // Custom bundles are disabled: price and credits are always decided by the server catalogue.
    const pkg = await resolvePackage(packageId);

    // Anti-abuse: limit unpaid orders (each call creates a purchases document)
    const recentPending = await db.collection('purchases')
      .where('userId', '==', callerUid).where('status', '==', 'pending').limit(30).get();
    const hourAgo = Date.now() - 3600 * 1000;
    if (recentPending.docs.filter((d) => Number(d.data().createdAt || 0) > hourAgo).length >= 10) {
      throw new functions.https.HttpsError('resource-exhausted', 'Too many checkout attempts. Please try again later.');
    }

    const userEmail = String(context.auth!.token.email || '');
    let userName = 'Maker';
    try {
      const userPubSnap = await db.doc(`users/${callerUid}`).get();
      userName = String(userPubSnap.data()?.displayName || 'Maker').slice(0, 100);
    } catch { /* ignore */ }

    const orderId = `ord_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const now = Date.now();

    // The order MUST exist before the customer can pay, otherwise a payment could never be credited.
    await db.doc(`purchases/${orderId}`).set({
      id: orderId,
      userId: callerUid,
      userEmail,
      userName,
      packageId,
      packageName: pkg.packageName,
      karmaAmount: pkg.karmaAmount,
      bonusKarma: pkg.bonusKarma,
      totalKarma: pkg.totalKarma,
      amountUsd: pkg.amountUsd,
      gateway: 'whop',
      gatewayTransactionId: '',
      whopPlanId: pkg.planId,
      status: 'pending',
      createdAt: now,
      metadata: { pushitOrderId: orderId, userId: callerUid, packageId, totalKarma: pkg.totalKarma, amountUsd: pkg.amountUsd },
    });

    const checkoutUrl =
      `https://whop.com/checkout/${encodeURIComponent(pkg.planId)}?email=${encodeURIComponent(userEmail)}` +
      `&metadata[pushitOrderId]=${encodeURIComponent(orderId)}&metadata[userId]=${encodeURIComponent(callerUid)}` +
      `&metadata[packageId]=${encodeURIComponent(packageId)}`;

    return { success: true, orderId, checkoutUrl, whopPlanId: pkg.planId, totalKarma: pkg.totalKarma, amountUsd: pkg.amountUsd };
  } catch (err: any) {
    const isHttpsError = err instanceof functions.https.HttpsError;
    functions.logger.error('createWhopCheckout Exception:', {
      errorMessage: err?.message || String(err),
      errorCode: isHttpsError ? err.code : 'internal',
      userId: callerUid,
      stack: err?.stack,
    });
    if (isHttpsError) throw err;
    throw new functions.https.HttpsError('internal', 'Could not start checkout. Please try again.');
  }
});

/**
 * 8. SERVER-SIDE VERIFY PURCHASE ORDER STATUS
 * Callable Cloud Function: verifyPurchaseOrder
 * - Allows client to check or manually verify payment status with Whop API
 * - Atomically fulfills order if Whop confirms payment succeeded
 */
export const verifyPurchaseOrder = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated.');
  }

  const orderId = assertDocId(data?.orderId, 'orderId');
  if (!orderId || typeof orderId !== 'string') {
    throw new functions.https.HttpsError('invalid-argument', 'Missing or invalid orderId.');
  }

  const callerUid = context.auth.uid;
  const isCallerAdmin = await checkIsAdmin(callerUid, context.auth.token.email);

  const orderRef = db.doc(`purchases/${orderId}`);
  const orderSnap = await orderRef.get();

  if (!orderSnap.exists) {
    throw new functions.https.HttpsError('not-found', 'Purchase order not found.');
  }

  const order = orderSnap.data()!;
  if (order.userId !== callerUid && !isCallerAdmin) {
    throw new functions.https.HttpsError('permission-denied', 'Unauthorized to inspect this purchase order.');
  }

  // If already completed or fulfilled, return status
  if (order.status === 'completed' || order.status === 'fulfilled' || order.status === 'paid') {
    return {
      success: true,
      status: 'completed',
      totalKarma: order.totalKarma,
      alreadyFulfilled: true,
    };
  }

  // Admin manual override (e.g. an order held for review that the admin confirmed in Whop's dashboard)
  if (isCallerAdmin && data?.adminOverride === true) {
    const r = await fulfillPurchaseOrder(orderId, String(data?.gatewayTransactionId || `ADMIN_${orderId}`), `admin_${callerUid}`, { adminOverride: true });
    return { success: r.fulfilled, status: r.fulfilled ? 'completed' : (order.status || 'pending'), totalKarma: order.totalKarma, justFulfilled: r.fulfilled };
  }

  // Attempt server verification with Whop API if API key exists
  const whopConfig = await getWhopConfig();
  if (whopConfig.apiKey) {
    try {
      // Query Whop payments API for this order metadata
      const paymentsRes = await safeFetch('https://api.whop.com/api/v5/payments', {
        headers: {
          Authorization: `Bearer ${whopConfig.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (paymentsRes.ok) {
        const paymentsData = await paymentsRes.json();
        const paymentList = paymentsData.data || paymentsData || [];
        
        // Find matching payment for this pushitOrderId
        const matchingPayment = paymentList.find((p: any) => {
          const meta = p.metadata || {};
          return meta.pushitOrderId === orderId || p.custom_fields?.pushitOrderId === orderId;
        });

        if (matchingPayment && (matchingPayment.status === 'paid' || matchingPayment.status === 'succeeded' || matchingPayment.paid === true)) {
          const whopPaymentId = matchingPayment.id || `WHOP_PAY_${Date.now()}`;
          
          const result = await fulfillPurchaseOrder(orderId, whopPaymentId, 'verify_purchase_order', {
            planId: extractPaidPlanId(matchingPayment),
          });

          return {
            success: result.fulfilled,
            status: result.fulfilled ? 'completed' : 'under_review',
            totalKarma: order.totalKarma,
            justFulfilled: result.fulfilled,
          };
        }
      } else {
        const errText = await paymentsRes.text().catch(() => '');
        functions.logger.error('verifyPurchaseOrder Whop Payments fetch failed:', paymentsRes.status, errText);
      }
    } catch (e: any) {
      functions.logger.error('[verifyPurchaseOrder Whop verify error]', {
        message: e?.message || String(e),
        stack: e?.stack,
        orderId,
      });
    }
  }

  return {
    success: true,
    status: order.status || 'pending',
    totalKarma: order.totalKarma,
  };
});


/**
 * Verifies a Whop webhook. Supports both:
 *  - Standard Webhooks (headers webhook-id / webhook-timestamp / webhook-signature "v1,<base64>"),
 *    rejecting timestamps older than 5 minutes (replay protection);
 *  - legacy plain HMAC-SHA256 hex of the raw body in x-whop-signature (optionally "sha256=" prefixed).
 * All comparisons are constant-time.
 */
function verifyWhopSignature(req: any, rawBody: string, secret: string): boolean {
  const safeEqual = (a: string, b: string) => {
    const ab = Buffer.from(a, 'utf-8');
    const bb = Buffer.from(b, 'utf-8');
    return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
  };

  // --- Standard Webhooks ---
  const msgId = req.headers['webhook-id'];
  const msgTs = req.headers['webhook-timestamp'];
  const msgSig = req.headers['webhook-signature'];
  if (typeof msgId === 'string' && typeof msgTs === 'string' && typeof msgSig === 'string') {
    const ts = Number(msgTs);
    if (!Number.isFinite(ts) || Math.abs(Date.now() / 1000 - ts) > 300) return false;
    const keys: Buffer[] = [Buffer.from(secret, 'utf-8')];
    if (secret.startsWith('whsec_')) {
      try { keys.push(Buffer.from(secret.slice(6), 'base64')); } catch { /* ignore */ }
    }
    const signed = `${msgId}.${msgTs}.${rawBody}`;
    const candidates = msgSig.split(' ').map((x) => x.trim()).filter(Boolean);
    for (const key of keys) {
      const expected = crypto.createHmac('sha256', key).update(signed).digest('base64');
      for (const c of candidates) {
        const value = c.startsWith('v1,') ? c.slice(3) : c;
        if (safeEqual(value, expected)) return true;
      }
    }
    return false;
  }

  // --- Legacy hex HMAC ---
  const legacy = req.headers['x-whop-signature'];
  if (typeof legacy === 'string') {
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    const value = legacy.startsWith('sha256=') ? legacy.slice(7) : legacy;
    return safeEqual(value, expected);
  }
  return false;
}

/**
 * 9. WHOP WEBHOOK HTTP ENDPOINT
 * HTTP Cloud Function: whopWebhook
 * - Idempotent server-authoritative payment confirmation
 * - Verifies Whop event, updates purchase status, credits KAR atomically
 */
export const whopWebhook = functions.region(REGION).https.onRequest(async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).send('Method Not Allowed');
    return;
  }

  try {
    const whopConfig = await getWhopConfig();
    const rawBody = (req as any).rawBody ? (req as any).rawBody.toString() : JSON.stringify(req.body);

    // FAIL-CLOSED WEBHOOK SIGNATURE VERIFICATION
    if (!whopConfig.webhookSecret) {
      console.error('[Whop Webhook Error] Webhook secret is not configured on server.');
      res.status(401).send('Webhook secret not configured.');
      return;
    }
    if (!verifyWhopSignature(req, rawBody, whopConfig.webhookSecret)) {
      console.error('[Whop Webhook Error] Invalid or missing webhook signature.');
      res.status(401).send('Invalid webhook signature.');
      return;
    }

    const payload = req.body || {};
    const eventType = payload.action || payload.event || '';
    const eventData = payload.data || payload;

    // Extract attached metadata
    const metadata = eventData.metadata || payload.metadata || {};
    const pushitOrderId = metadata.pushitOrderId || eventData.custom_fields?.pushitOrderId || '';

    if (/refund|dispute|chargeback/i.test(String(eventType))) {
      // The order is identified by the PAYMENT id stored at fulfilment, never by metadata alone:
      // metadata is typed by the customer in the checkout link and could point at somebody else's order.
      const txId = String(eventData.payment_id || eventData.id || '');
      let targetOrderId = '';
      if (txId) {
        const q = await db.collection('purchases').where('gatewayTransactionId', '==', txId).limit(1).get();
        if (!q.empty) targetOrderId = q.docs[0].id;
      }
      if (!targetOrderId) {
        res.status(200).json({ received: true, note: 'Reversal event for unknown payment' });
        return;
      }
      const r = await reversePurchaseOrder(assertDocId(targetOrderId, 'orderId'), String(eventType).slice(0, 80));
      functions.logger.warn('[Whop Webhook] Payment reversal processed', { orderId: targetOrderId, ...r });
      res.status(200).json({ success: true, reversed: r.reversed });
      return;
    }

    if (!pushitOrderId) {
      console.log('[Whop Webhook] Non-PUSHIT or unmapped Whop webhook event received:', eventType);
      res.status(200).json({ received: true, note: 'Unmapped metadata' });
      return;
    }

    if (!DOC_ID_RE.test(String(pushitOrderId))) {
      res.status(200).json({ received: true, note: 'Invalid order reference' });
      return;
    }

    const isSuccessEvent =
      /succeed|paid|completed/i.test(String(eventType)) ||
      eventData.status === 'paid' || eventData.paid === true || eventData.succeeded === true;
    if (!isSuccessEvent) {
      res.status(200).json({ received: true, note: 'Ignored non-success event' });
      return;
    }

    const gatewayTransactionId = eventData.id || eventData.payment_id || `WHOP_WEB_${Date.now()}`;

    const result = await fulfillPurchaseOrder(pushitOrderId, gatewayTransactionId, 'whop_webhook', {
      planId: extractPaidPlanId(eventData),
    });

    res.status(200).json({ success: result.fulfilled, orderId: pushitOrderId, note: result.reason || 'ok' });
  } catch (err: any) {
    console.error('[Whop Webhook Handler Error]', err);
    res.status(500).json({ error: err?.message || 'Webhook processing failed' });
  }
});

/**
 * 10. DEDUCT CREDITS FOR CAMPAIGN
 * Callable Cloud Function: deductCreditsForCampaign
 */
export const deductCreditsForCampaign = functions.region(REGION).https.onCall(async () => {
  // Permanently disabled (kept as an export so existing deployments do not break).
  throw new functions.https.HttpsError('failed-precondition', 'This operation is no longer available.');
});

/**
 * 11. BUY P2P OFFER (Atomic Dual-Token Transaction with 20% Fee, 10% Burn, 70% Seller)
 * Callable Cloud Function: buyP2POffer
 */
export const buyP2POffer = functions.region(REGION).https.onCall(async () => {
  // Permanently disabled (kept as an export so existing deployments do not break).
  throw new functions.https.HttpsError('failed-precondition', 'P2P token trading is disabled.');
});

/**
 * 12. REFUND CAMPAIGN (Dual-Token Exact Refund)
 * Callable Cloud Function: refundCampaign
 * - Checks project status not already refunded/deleted
 * - Reads project.spentPaidKAR and project.spentRewardKAR
 * - Refunds project.spentPaidKAR to owner's karmaPaid
 * - Refunds project.spentRewardKAR to owner's karmaReward
 * - Marks project as deleted/refunded
 */
export const refundCampaign = functions.region(REGION).https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated.');
  }

  const projectId = assertDocId(data?.projectId, 'projectId');
  if (!projectId || typeof projectId !== 'string') {
    throw new functions.https.HttpsError('invalid-argument', 'Missing or invalid projectId.');
  }

  const callerUid = context.auth.uid;
  const callerEmail = context.auth.token.email;
  const isCallerAdmin = await checkIsAdmin(callerUid, callerEmail);
  const now = Date.now();

  return await db.runTransaction(async (transaction) => {
    const projRef = db.doc(`projects/${projectId}`);
    const projSnap = await transaction.get(projRef);
    if (!projSnap.exists) {
      throw new functions.https.HttpsError('not-found', 'Project not found.');
    }

    const projData = projSnap.data()!;
    // Guard against duplicate refunds
    if (projData.status === 'deleted' || projData.status === 'refunded' || Boolean(projData.refundedAt)) {
      return {
        success: true,
        alreadyRefunded: true,
        refundedPaid: 0,
        refundedReward: 0,
        refundedKarma: 0,
      };
    }

    if (projData.ownerId !== callerUid && !isCallerAdmin) {
      throw new functions.https.HttpsError('permission-denied', 'You do not have permission to refund this campaign.');
    }

    const ownerId = projData.ownerId;
    const userPrivRef = db.doc(`usersPrivate/${ownerId}`);
    const userPrivSnap = await transaction.get(userPrivRef);
    if (!userPrivSnap.exists) {
      throw new functions.https.HttpsError('not-found', 'Owner account not found.');
    }

    const uData = userPrivSnap.data()!;
    const { paid: currentPaid, reward: currentReward } = getPools(uData);

    if (!isCallerAdmin) {
      const awaiting = await transaction.get(
        db.collection('commitments')
          .where('projectId', '==', projectId)
          .where('proofStatus', '==', 'pending')
          .where('status', '==', 'completed')
          .limit(1)
      );
      if (!awaiting.empty) {
        throw new functions.https.HttpsError('failed-precondition', 'PENDING_SUBMISSIONS: review the submitted proofs (approve or reject) before refunding this campaign.');
      }
    }

    const rewardPerPush = rewardPerResult(projData);

    const allocatedBudget = typeof projData.budgetKarma === 'number' && projData.budgetKarma > 0
      ? projData.budgetKarma
      : Number(projData.targetGoal || 10) * rewardPerPush;

    // Source of truth: compute verified task payouts from confirmed commitments
    const commsQuery = db.collection('commitments')
      .where('projectId', '==', projectId)
      .where('proofStatus', '==', 'confirmed');
    const commsSnap = await transaction.get(commsQuery);

    let verifiedConfirmedSpend = 0;
    commsSnap.forEach((docSnap) => {
      const cData = docSnap.data();
      verifiedConfirmedSpend += Number(cData.rewardAmount || rewardPerPush);
    });

    const recordedSpentKarma = typeof projData.spentKarma === 'number' ? projData.spentKarma : 0;
    const actualSpentKarma = Math.max(verifiedConfirmedSpend, recordedSpentKarma);
    const unspentRefund = Math.max(0, allocatedBudget - actualSpentKarma);

    const hasDualTokens = typeof projData.spentPaidKAR === 'number' || typeof projData.spentRewardKAR === 'number';
    const spentPaid = Number(projData.spentPaidKAR ?? 0);
    const spentReward = Number(projData.spentRewardKAR ?? 0);

    let refundPaid = 0;
    let refundReward = 0;

    if (allocatedBudget <= 0 || unspentRefund <= 0) {
      refundPaid = 0;
      refundReward = 0;
    } else if (hasDualTokens) {
      const unspentRatio = Math.min(1, unspentRefund / allocatedBudget);
      refundPaid = Math.floor(spentPaid * unspentRatio);
      refundReward = Math.floor(spentReward * unspentRatio);
    } else {
      refundPaid = unspentRefund;
      refundReward = 0;
    }

    const newPaid = currentPaid + refundPaid;
    const newReward = currentReward + refundReward;
    const newTotalKarma = newPaid + newReward;
    const totalRefundKarma = refundPaid + refundReward;

    if (refundPaid > 0 || refundReward > 0) {
      transaction.update(userPrivRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newTotalKarma,
        submissionSlots: Math.max(0, Math.floor(newTotalKarma / 20)),
        updatedAt: now,
      });

      const txRef = db.collection('karmaTransactions').doc(`tx_refund_campaign_${projectId}_${now}`);
      transaction.set(txRef, {
        id: txRef.id,
        userId: ownerId,
        amount: totalRefundKarma,
        type: 'CAMPAIGN_DELETE_REFUND',
        description: `Campaign refund: restored ${refundPaid} KAR and ${refundReward} rKAR (unspent: ${unspentRefund} KAR)`,
        referenceId: projectId,
        balanceAfter: newTotalKarma,
        createdAt: now,
        createdBy: callerUid,
        metadata: {
          projectId,
          allocatedBudget,
          actualSpentKarma,
          verifiedConfirmedSpend,
          unspentRefund,
          refundPaid,
          refundReward,
        },
      });
    }

    transaction.update(projRef, {
      status: 'refunded',
      refundedAt: now,
      refundedPaid: refundPaid,
      refundedReward: refundReward,
      refundedKarma: totalRefundKarma,
      updatedAt: now,
    });

    return {
      success: true,
      refundedPaid: refundPaid,
      refundedReward: refundReward,
      refundedKarma: totalRefundKarma,
      newTotalKarma,
    };
  });
});

/* ======================================================================================
 * NEW SERVER-AUTHORITATIVE OPERATIONS
 * Everything that moves credits or money now happens here. Clients can no longer write
 * to usersPrivate / karmaTransactions / purchases / withdrawals (see firestore.rules).
 * ==================================================================================== */

// Business-rule switches (flip to false if you want a different policy)
const WITHDRAW_ONLY_EARNED = true;          // only credits EARNED from tasks can be cashed out (not purchased credits)
const REQUIRE_PHONE_FOR_WITHDRAWAL = true;  // verified phone number required to withdraw
const WITHDRAW_MIN = 50;
const WITHDRAW_MAX = 1000000;

/**
 * A. BOOTSTRAP ADMIN CLAIM
 * An admin signs in once with a VERIFIED listed email; this sets the `admin` custom claim
 * that firestore.rules rely on. The client then refreshes its ID token.
 */
export const bootstrapAdminClaim = functions.region(REGION).https.onCall(async (_data, context) => {
  const uid = requireAuth(context);
  const rec = await admin.auth().getUser(uid);
  if (!(rec.email && rec.emailVerified && ADMIN_EMAILS.includes(rec.email.toLowerCase()))) {
    throw new functions.https.HttpsError('permission-denied', 'Not an administrator.');
  }
  if ((rec.customClaims as any)?.admin !== true) {
    await admin.auth().setCustomUserClaims(uid, { ...(rec.customClaims || {}), admin: true });
  }
  await db.doc(`usersPrivate/${uid}`).set({ isAdmin: true, updatedAt: Date.now() }, { merge: true });
  return { success: true };
});

/**
 * B. REQUEST WITHDRAWAL (escrow credits atomically)
 */
export const requestWithdrawal = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  const amount = toSafeInt(data?.amount, WITHDRAW_MIN, WITHDRAW_MAX, 'amount');
  const method = String(data?.method || '').trim();
  const accountDetails = String(data?.accountDetails || '').trim();
  if (!method || method.length > 50) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid withdrawal method.');
  }
  if (accountDetails.length < 3 || accountDetails.length > 300) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid account details.');
  }

  const anyMethod = await db.collection('withdrawal_methods').limit(1).get();
  if (!anyMethod.empty) {
    const m = await db.doc(`withdrawal_methods/${method}`).get();
    if (!m.exists || m.data()?.enabled === false) {
      throw new functions.https.HttpsError('invalid-argument', 'This withdrawal method is not available.');
    }
    if (amount < Number(m.data()?.minAmount || WITHDRAW_MIN)) {
      throw new functions.https.HttpsError('invalid-argument', `Minimum for this method is ${m.data()?.minAmount}.`);
    }
  }

  const pending = await db.collection('withdrawals').where('userId', '==', uid).where('status', '==', 'pending').limit(1).get();
  if (!pending.empty) {
    throw new functions.https.HttpsError('failed-precondition', 'You already have a pending withdrawal request.');
  }

  if (context.auth!.token.email_verified !== true) {
    throw new functions.https.HttpsError('failed-precondition', 'EMAIL_NOT_VERIFIED: verify your email address before withdrawing.');
  }
  const authRec = await admin.auth().getUser(uid);
  const ageDays = (Date.now() - new Date(authRec.metadata.creationTime).getTime()) / 86400000;
  if (ageDays < MIN_ACCOUNT_AGE_DAYS_FOR_WITHDRAWAL) {
    throw new functions.https.HttpsError('failed-precondition', `ACCOUNT_TOO_NEW: withdrawals open ${MIN_ACCOUNT_AGE_DAYS_FOR_WITHDRAWAL} days after sign-up.`);
  }

  // Risk signals stored with the request so the reviewer can spot self-dealing
  // (an account whose earnings come almost entirely from ONE advertiser).
  const confirmedSnap = await db.collection('commitments')
    .where('userId', '==', uid).where('proofStatus', '==', 'confirmed').limit(200).get();
  const earnedPerProject: Record<string, number> = {};
  confirmedSnap.forEach((d) => {
    const c = d.data();
    earnedPerProject[c.projectId] = (earnedPerProject[c.projectId] || 0) + Number(c.rewardAmount || 0);
  });
  const advertiserTotals: Record<string, number> = {};
  const projectIdsForRisk = Object.keys(earnedPerProject).filter((id) => DOC_ID_RE.test(id)).slice(0, 60);
  if (projectIdsForRisk.length > 0) {
    const projectSnaps = await db.getAll(...projectIdsForRisk.map((id) => db.doc(`projects/${id}`)));
    projectSnaps.forEach((sn) => {
      const owner = sn.exists ? String(sn.data()!.ownerId || 'unknown') : 'deleted-campaign';
      advertiserTotals[owner] = (advertiserTotals[owner] || 0) + earnedPerProject[sn.id];
    });
  }
  const earnedFromTasks = Object.values(advertiserTotals).reduce((a, b) => a + b, 0);
  const topAdvertiserShare = earnedFromTasks > 0 ? Math.max(...Object.values(advertiserTotals)) / earnedFromTasks : 0;
  const risk = {
    accountAgeDays: round2(ageDays),
    confirmedTasks: confirmedSnap.size,
    distinctAdvertisers: Object.keys(advertiserTotals).length,
    topAdvertiserShare: round2(topAdvertiserShare),
    selfDealingSuspect: topAdvertiserShare >= 0.9 && earnedFromTasks >= 100,
  };

  const email = String(context.auth!.token.email || '');
  const pub = await db.doc(`users/${uid}`).get();
  const userName = String(pub.data()?.displayName || 'Creator').slice(0, 100);
  const now = Date.now();

  return await db.runTransaction(async (tx) => {
    const privRef = db.doc(`usersPrivate/${uid}`);
    const snap = await tx.get(privRef);
    if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Account not found.');
    const u = snap.data()!;
    if (u.isBanned === true) throw new functions.https.HttpsError('permission-denied', 'This account is suspended.');
    if (u.payoutHold === true || Number(u.chargebackDebt || 0) > 0) {
      throw new functions.https.HttpsError('failed-precondition', 'PAYOUT_HOLD: withdrawals are paused on this account. Please contact support.');
    }
    if (REQUIRE_PHONE_FOR_WITHDRAWAL && !(u.phoneVerified === true && u.phoneHash)) {
      throw new functions.https.HttpsError('failed-precondition', 'PHONE_VERIFICATION_REQUIRED: verify your phone number before withdrawing.');
    }

    const { paid, reward } = getPools(u);
    const available = WITHDRAW_ONLY_EARNED ? reward : paid + reward;
    if (amount > available) {
      throw new functions.https.HttpsError('failed-precondition', `Insufficient withdrawable balance. Available: ${available} Credits.`);
    }

    const fromReward = Math.min(reward, amount);
    const fromPaid = amount - fromReward;
    const newReward = reward - fromReward;
    const newPaid = paid - fromPaid;
    const newBalance = newPaid + newReward;

    const wdRef = db.collection('withdrawals').doc();
    const ledgerRef = db.collection('karmaTransactions').doc(`tx_wd_${wdRef.id}`);

    tx.set(wdRef, {
      id: wdRef.id,
      userId: uid,
      userEmail: email,
      userName,
      amount,
      method,
      accountDetails,
      escrow: { reward: fromReward, paid: fromPaid },
      // value locked at request time so later rate changes never alter what the creator is owed
      risk,
      usdPerCredit: PAYOUT_USD_PER_CREDIT,
      amountUsd: round2(amount * PAYOUT_USD_PER_CREDIT),
      feeUsd: round2(amount * PAYOUT_USD_PER_CREDIT * WITHDRAWAL_FEE_PERCENT / 100),
      netUsd: round2(amount * PAYOUT_USD_PER_CREDIT * (1 - WITHDRAWAL_FEE_PERCENT / 100)),
      status: 'pending',
      createdAt: FieldValue.serverTimestamp(),
    });
    tx.update(privRef, {
      karmaPaid: newPaid,
      karmaReward: newReward,
      karma: newBalance,
      lifetimeSpent: Number(u.lifetimeSpent ?? 0) + amount,
      submissionSlots: Math.max(0, Math.floor(newBalance / 20)),
      updatedAt: now,
    });
    tx.set(ledgerRef, {
      id: ledgerRef.id,
      userId: uid,
      amount: -amount,
      type: 'WITHDRAWAL_REQUEST',
      description: `Withdrawal request: ${amount} Credits via ${method.toUpperCase()}`,
      referenceId: wdRef.id,
      balanceAfter: newBalance,
      createdAt: now,
      createdBy: uid,
      metadata: { method },
    });
    return { success: true, withdrawalId: wdRef.id, newBalance };
  });
});

/**
 * C. REVIEW WITHDRAWAL (admin only). Rejection refunds the exact pools that were escrowed.
 */
export const reviewWithdrawal = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  if (!(await checkIsAdmin(uid))) {
    throw new functions.https.HttpsError('permission-denied', 'Administrators only.');
  }
  const withdrawalId = assertDocId(data?.withdrawalId, 'withdrawalId');
  const status = String(data?.status || '');
  const adminNotes = String(data?.adminNotes || '').slice(0, 500);
  if (!withdrawalId || (status !== 'approved' && status !== 'rejected')) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid request.');
  }
  const now = Date.now();

  return await db.runTransaction(async (tx) => {
    const wdRef = db.doc(`withdrawals/${withdrawalId}`);
    const wdSnap = await tx.get(wdRef);
    if (!wdSnap.exists) throw new functions.https.HttpsError('not-found', 'Withdrawal not found.');
    const wd = wdSnap.data()!;
    if (wd.status !== 'pending') {
      throw new functions.https.HttpsError('failed-precondition', `Withdrawal is already ${wd.status}.`);
    }

    let privSnap: any = null;
    const privRef = db.doc(`usersPrivate/${wd.userId}`);
    if (status === 'rejected') privSnap = await tx.get(privRef);

    tx.update(wdRef, { status, processedAt: FieldValue.serverTimestamp(), processedBy: uid, adminNotes });

    if (status === 'approved') {
      const entry = platformLedgerEntry('PAYOUT', withdrawalId, {
        userId: wd.userId,
        credits: -Number(wd.amount),
        amountUsd: -Number(wd.netUsd ?? round2(Number(wd.amount) * PAYOUT_USD_PER_CREDIT)),
        feeUsd: Number(wd.feeUsd || 0),
        method: String(wd.method || ''),
      });
      tx.set(entry.ref, entry.data);
    }

    if (status === 'rejected' && privSnap && privSnap.exists) {
      const u = privSnap.data()!;
      const escrow = wd.escrow || { reward: Number(wd.amount), paid: 0 };
      const pools = getPools(u);
      const newPaid = pools.paid + Number(escrow.paid || 0);
      const newReward = pools.reward + Number(escrow.reward || 0);
      const newBalance = newPaid + newReward;
      tx.update(privRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        lifetimeSpent: Math.max(0, Number(u.lifetimeSpent ?? 0) - Number(wd.amount)),
        submissionSlots: Math.max(0, Math.floor(newBalance / 20)),
        updatedAt: now,
      });
      const refundRef = db.collection('karmaTransactions').doc(`tx_wd_ref_${withdrawalId}`);
      tx.set(refundRef, {
        id: refundRef.id,
        userId: wd.userId,
        amount: Number(wd.amount),
        type: 'WITHDRAWAL_REFUND',
        description: `Withdrawal rejected & refunded: +${wd.amount} Credits (${adminNotes || 'Declined'})`,
        referenceId: withdrawalId,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: uid,
        metadata: { withdrawalId, reason: adminNotes },
      });
    }
    return { success: true, userId: wd.userId, amount: Number(wd.amount), method: String(wd.method || '') };
  });
});

/**
 * D. CREATE CAMPAIGN (budget is escrowed server-side)
 */
const ADVERTISER_TERMS_VERSION = '2026-11-22';

const PROTECTED_PROJECT_KEYS = [
  'termsAccepted', 'advertiserTermsAcceptedAt', 'advertiserTermsVersion', 'completedBy',
  'id', 'ownerId', 'pushCount', 'completedCount', 'confirmedCount', 'spentKarma',
  'spentPaidKAR', 'spentRewardKAR', 'budgetKarma', 'targetGoal', 'costPerResultKarma',
  'status', 'totalViews', 'isOfficialPromoTask', 'featured', 'createdAt', 'updatedAt', 'refundedAt',
];

const stripUndefined = (obj: any): any => JSON.parse(JSON.stringify(obj));

const isHttpUrl = (v: any): boolean => {
  if (v === undefined || v === null || v === '') return true;
  if (typeof v !== 'string' || v.length > 2000) return false;
  try {
    const u = new URL(v.trim());
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
};

export const createCampaign = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  await assertNotBanned(uid);
  const isAdminUser = await checkIsAdmin(uid);

  const input = data?.project;
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing campaign data.');
  }
  if (!isAdminUser && input.termsAccepted !== true) {
    throw new functions.https.HttpsError('failed-precondition', 'TERMS_NOT_ACCEPTED: accept the advertiser terms before publishing.');
  }
  const title = String(input.title || '').trim();
  if (!title || title.length > 150) {
    throw new functions.https.HttpsError('invalid-argument', 'Campaign title is required (max 150 chars).');
  }

  const promotionType = String(input.promotionType || '');
  const campaignType = String(input.campaignType || '');
  const isUgc = promotionType === 'ugc' || campaignType.toLowerCase().includes('ugc');
  const unitCost = defaultRewardForType(promotionType, campaignType); // fixed by type, not chosen by the client
  const minBudget = isUgc ? 40 : 20;
  const budget = toSafeInt(input.budgetKarma ?? minBudget, minBudget, 1000000, 'budget');
  const targetGoal = Math.max(1, Math.floor(budget / unitCost));

  const clean = stripUndefined(input);
  PROTECTED_PROJECT_KEYS.forEach((k) => delete clean[k]);

  // Only http(s) links are allowed (blocks javascript:/data: stored-XSS payloads)
  const urlFields = ['projectUrl', 'boostTargetUrl', 'sourceMaterialUrl'];
  for (const f of urlFields) {
    if (!isHttpUrl(clean[f])) {
      throw new functions.https.HttpsError('invalid-argument', `Invalid link in "${f}". Use a full http(s) URL.`);
    }
  }
  if (clean.socialLinks && typeof clean.socialLinks === 'object') {
    for (const [k, v] of Object.entries(clean.socialLinks)) {
      if (!isHttpUrl(v)) {
        throw new functions.https.HttpsError('invalid-argument', `Invalid social link "${k}".`);
      }
    }
  }
  if (typeof clean.description === 'string' && clean.description.length > 10000) {
    throw new functions.https.HttpsError('invalid-argument', 'Description is too long.');
  }

  const pub = await db.doc(`users/${uid}`).get();
  const projRef = db.collection('projects').doc();
  const now = Date.now();
  const project: any = {
    ...clean,
    id: projRef.id,
    title,
    ownerId: uid,
    ownerName: String(clean.ownerName || pub.data()?.displayName || 'Creator').slice(0, 100),
    pushCount: 0,
    completedCount: 0,
    confirmedCount: 0,
    targetGoal,
    budgetKarma: budget,
    spentKarma: 0,
    costPerResultKarma: unitCost,
    status: 'active',
    campaignTier: String(clean.campaignTier || 'custom').slice(0, 30),
    totalViews: 0,
    isOfficialPromoTask: isAdminUser && input.isOfficialPromoTask === true,
    featured: false,
    advertiserTermsAcceptedAt: now,
    advertiserTermsVersion: ADVERTISER_TERMS_VERSION,
    createdAt: now,
    updatedAt: now,
  };
  if (Array.isArray(project.images)) project.images = project.images.slice(0, 3);
  if (JSON.stringify(project).length > 950000) {
    throw new functions.https.HttpsError('invalid-argument', 'Campaign is too large. Please use smaller or fewer images.');
  }

  await db.runTransaction(async (tx) => {
    const privRef = db.doc(`usersPrivate/${uid}`);
    const snap = await tx.get(privRef);
    if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Account not found.');
    const u = snap.data()!;

    let fundedPaid = 0;
    let fundedReward = 0;
    if (!isAdminUser) {
      const { paid, reward } = getPools(u);
      const balance = paid + reward;
      if (balance < budget) {
        throw new functions.https.HttpsError('failed-precondition', `INSUFFICIENT_CREDITS: You need ${budget} Credits, your balance is ${balance}.`);
      }
      const fromPaid = Math.min(paid, budget);
      const fromReward = budget - fromPaid;
      fundedPaid = fromPaid;
      fundedReward = fromReward;
      const newPaid = paid - fromPaid;
      const newReward = reward - fromReward;
      const newBalance = newPaid + newReward;
      const ledgerRef = db.collection('karmaTransactions').doc(`tx_promo_${projRef.id}`);
      tx.set(ledgerRef, {
        id: ledgerRef.id,
        userId: uid,
        amount: -budget,
        type: 'CAMPAIGN_BUDGET',
        description: `Allocated campaign budget (${targetGoal} verified ${promotionType || 'clips'}): ${title}`,
        referenceId: projRef.id,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: uid,
        metadata: { projectId: projRef.id, cost: budget, budgetKarma: budget, targetGoal, promotionType },
      });
      tx.update(privRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        lifetimeSpent: Number(u.lifetimeSpent ?? 0) + budget,
        submissionSlots: Math.max(0, Math.floor(newBalance / 20)),
        updatedAt: now,
      });
    }
    // Funding record: refunds return to the pools that paid (admin/official campaigns fund nothing => refund nothing)
    project.spentPaidKAR = fundedPaid;
    project.spentRewardKAR = fundedReward;
    tx.set(projRef, project);
  });

  return { success: true, projectId: projRef.id, project };
});

/**
 * E. INCREASE CAMPAIGN BUDGET
 */
export const increaseCampaignBudget = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  await assertNotBanned(uid);
  const isAdminUser = await checkIsAdmin(uid);
  const projectId = assertDocId(data?.projectId, 'projectId');
  const newBudget = toSafeInt(data?.newBudget, 1, 1000000, 'budget');
  const now = Date.now();

  return await db.runTransaction(async (tx) => {
    const projRef = db.doc(`projects/${projectId}`);
    const projSnap = await tx.get(projRef);
    if (!projSnap.exists) throw new functions.https.HttpsError('not-found', 'Campaign not found.');
    const p = projSnap.data()!;
    if (p.ownerId !== uid && !isAdminUser) {
      throw new functions.https.HttpsError('permission-denied', 'You do not own this campaign.');
    }
    if (p.status === 'deleted' || p.status === 'refunded') {
      throw new functions.https.HttpsError('failed-precondition', 'This campaign was deleted.');
    }

    const rewardPerPush = rewardPerResult(p);
    const spentKarma = typeof p.spentKarma === 'number' ? p.spentKarma : Number(p.pushCount || 0) * rewardPerPush;
    const currentBudget = typeof p.budgetKarma === 'number' ? p.budgetKarma : Number(p.targetGoal || 10) * rewardPerPush;
    const minAllowed = Math.max(rewardPerPush, spentKarma);
    if (newBudget < minAllowed) {
      throw new functions.https.HttpsError('invalid-argument', `INVALID_BUDGET: Budget cannot be less than ${minAllowed} Credits.`);
    }
    const delta = newBudget - currentBudget;
    if (delta < 0) {
      throw new functions.https.HttpsError('failed-precondition', 'BUDGET_DECREASE_FORBIDDEN: Budgets can only be increased.');
    }
    if (delta === 0) return { success: true, newBudget, delta: 0, isRefund: false };

    // owner's account pays (an admin editing someone else's campaign adds budget for free)
    const payerIsOwner = p.ownerId === uid;
    let addPaid = 0;
    let addReward = 0;
    if (payerIsOwner && !isAdminUser) {
      const privRef = db.doc(`usersPrivate/${uid}`);
      const snap = await tx.get(privRef);
      if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Account not found.');
      const u = snap.data()!;
      const { paid, reward } = getPools(u);
      if (paid + reward < delta) {
        throw new functions.https.HttpsError('failed-precondition', `INSUFFICIENT_CREDITS: Need ${delta} Credits, balance is ${paid + reward}.`);
      }
      const fromPaid = Math.min(paid, delta);
      addPaid = fromPaid;
      addReward = delta - fromPaid;
      const newPaid = paid - fromPaid;
      const newReward = reward - (delta - fromPaid);
      const newBalance = newPaid + newReward;
      const ledgerRef = db.collection('karmaTransactions').doc(`tx_budget_inc_${projectId}_${now}`);
      tx.set(ledgerRef, {
        id: ledgerRef.id,
        userId: uid,
        amount: -delta,
        type: 'BUDGET_INCREASE',
        description: `Increased campaign budget (+${delta} Credits): ${p.title}`,
        referenceId: projectId,
        balanceAfter: newBalance,
        createdAt: now,
        createdBy: uid,
        metadata: { projectId, oldBudget: currentBudget, newBudget, delta },
      });
      tx.update(privRef, {
        karmaPaid: newPaid,
        karmaReward: newReward,
        karma: newBalance,
        lifetimeSpent: Number(u.lifetimeSpent ?? 0) + delta,
        submissionSlots: Math.max(0, Math.floor(newBalance / 20)),
        updatedAt: now,
      });
    }

    // legacy campaigns have no funding record: assume their existing budget was paid with purchased credits
    const basePaid = typeof p.spentPaidKAR === 'number' ? p.spentPaidKAR : (p.isOfficialPromoTask ? 0 : currentBudget);
    const baseReward = typeof p.spentRewardKAR === 'number' ? p.spentRewardKAR : 0;
    tx.update(projRef, {
      spentPaidKAR: basePaid + addPaid,
      spentRewardKAR: baseReward + addReward,
      budgetKarma: newBudget,
      targetGoal: Math.max(1, Math.floor(newBudget / rewardPerPush)),
      costPerResultKarma: rewardPerPush,
      spentKarma,
      updatedAt: now,
    });
    return { success: true, newBudget, delta, isRefund: false };
  });
});

/**
 * F. REPORT DELETED VIDEO (campaign owner flags a deliverable; admins are notified privately)
 */
export const reportDeletedVideo = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  const isAdminUser = await checkIsAdmin(uid);
  const commitmentId = assertDocId(data?.commitmentId, 'commitmentId');
  const reason = String(data?.reason || 'Video was deleted or made private after approval').slice(0, 500);
  if (!commitmentId) throw new functions.https.HttpsError('invalid-argument', 'Missing commitmentId.');

  const commRef = db.doc(`commitments/${commitmentId}`);
  const commSnap = await commRef.get();
  if (!commSnap.exists) throw new functions.https.HttpsError('not-found', 'Commitment not found.');
  const c = commSnap.data()!;
  const projSnap = await db.doc(`projects/${c.projectId}`).get();
  if (!projSnap.exists || (projSnap.data()!.ownerId !== uid && !isAdminUser)) {
    throw new functions.https.HttpsError('permission-denied', 'Only the campaign owner can report this deliverable.');
  }
  if (c.proofStatus !== 'confirmed') {
    throw new functions.https.HttpsError('failed-precondition', 'Only approved deliverables can be disputed.');
  }
  const now = Date.now();
  await commRef.update({
    deletedReported: true,
    deletedReportedAt: now,
    deletionReportReason: reason,
    deletionReportedBy: uid,
    deletionResolved: false,
  });

  for (const email of ADMIN_EMAILS) {
    try {
      const adminUser = await admin.auth().getUserByEmail(email);
      const id = `notif_${now}_${crypto.randomBytes(3).toString('hex')}`;
      await db.doc(`notifications/${id}`).set({
        id,
        userId: adminUser.uid,
        title: '🚨 Video Deletion Dispute Reported',
        message: `Deleted deliverable reported on "${String(c.projectTitle || 'Campaign').slice(0, 100)}" (${commitmentId}): ${reason}`,
        targetUrl: '/admin?tab=moderation&status=reported_deletion',
        type: 'dispute',
        read: false,
        createdAt: now,
        senderName: 'Dispute System',
        senderAvatar: '',
      });
    } catch {
      // admin account may not exist yet
    }
  }
  return { success: true };
});

/**
 * G. ADMIN: ADJUST / SET USER CREDITS (audited)
 */
export const adminAdjustKarma = functions.region(REGION).https.onCall(async (data, context) => {
  const adminUid = requireAuth(context);
  if (!(await checkIsAdmin(adminUid))) {
    throw new functions.https.HttpsError('permission-denied', 'Administrators only.');
  }
  const userId = assertDocId(data?.userId, 'userId');
  const reason = String(data?.reason || '').slice(0, 300);
  if (!userId) throw new functions.https.HttpsError('invalid-argument', 'Missing userId.');
  const hasSet = data?.setBalance !== undefined && data?.setBalance !== null;
  const setBalance = hasSet ? toSafeInt(data.setBalance, 0, 10000000, 'setBalance') : 0;
  const amountIn = hasSet ? 0 : toSafeInt(data?.amount, -10000000, 10000000, 'amount');
  const now = Date.now();

  return await db.runTransaction(async (tx) => {
    const privRef = db.doc(`usersPrivate/${userId}`);
    const snap = await tx.get(privRef);
    if (!snap.exists) throw new functions.https.HttpsError('not-found', 'User not found.');
    const u = snap.data()!;
    const { paid, reward } = getPools(u);
    const balance = paid + reward;
    const delta = hasSet ? setBalance - balance : amountIn;
    let newPaid = paid;
    let newReward = reward;
    if (delta >= 0) {
      newReward += delta;
    } else {
      const take = -delta;
      const fromReward = Math.min(reward, take);
      newReward -= fromReward;
      newPaid = Math.max(0, paid - (take - fromReward));
    }
    const newBalance = newPaid + newReward;
    const ledgerRef = db.collection('karmaTransactions').doc(`tx_admin_${userId}_${now}`);
    tx.set(ledgerRef, {
      id: ledgerRef.id,
      userId,
      amount: newBalance - balance,
      type: 'ADMIN_ADJUSTMENT',
      description: reason || `Admin adjustment (${delta >= 0 ? '+' : ''}${delta} KAR)`,
      referenceId: `admin_${adminUid}_${now}`,
      balanceAfter: newBalance,
      createdAt: now,
      createdBy: adminUid,
      metadata: { reason, adjustedBy: adminUid },
    });
    const update: Record<string, any> = {
      karmaPaid: newPaid,
      karmaReward: newReward,
      karma: newBalance,
      lifetimeEarned: Number(u.lifetimeEarned ?? 0) + Math.max(0, delta),
      lifetimeSpent: Number(u.lifetimeSpent ?? 0) + Math.max(0, -delta),
      updatedAt: now,
    };
    update.submissionSlots =
      data?.submissionSlots !== undefined && data?.submissionSlots !== null
        ? toSafeInt(data.submissionSlots, 0, 100000, 'submissionSlots')
        : Math.max(0, Math.floor(newBalance / 20));
    tx.update(privRef, update);
    return { success: true, newBalance };
  });
});

/**
 * H. DELETE MY ACCOUNT (server-side: works even when the login session is old, and never orphans money)
 */
export const deleteMyAccount = functions.region(REGION).https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  if (await checkIsAdmin(uid)) {
    throw new functions.https.HttpsError('failed-precondition', 'Administrator accounts cannot be deleted here.');
  }
  const confirmForfeit = data?.confirmForfeit === true;

  const pendingWd = await db.collection('withdrawals').where('userId', '==', uid).where('status', '==', 'pending').limit(1).get();
  if (!pendingWd.empty) {
    throw new functions.https.HttpsError('failed-precondition', 'PENDING_WITHDRAWAL: wait until your withdrawal request is processed.');
  }
  const ownedCampaigns = await db.collection('projects').where('ownerId', '==', uid).limit(20).get();
  const live = ownedCampaigns.docs.filter((d) => !['deleted', 'refunded'].includes(String(d.data().status || '')));
  if (live.length > 0) {
    throw new functions.https.HttpsError('failed-precondition', 'ACTIVE_CAMPAIGNS: delete your campaigns first so unspent budget is refunded.');
  }

  const privRef = db.doc(`usersPrivate/${uid}`);
  const privSnap = await privRef.get();
  const balance = privSnap.exists ? getPools(privSnap.data()).total : 0;
  if (balance > 0 && !confirmForfeit) {
    throw new functions.https.HttpsError('failed-precondition', `BALANCE_NOT_EMPTY:${balance}`);
  }

  // Private + public profile and notifications are erased; ledger/commitments are kept for accounting.
  const batch = db.batch();
  batch.delete(privRef);
  batch.delete(db.doc(`users/${uid}`));
  const notifs = await db.collection('notifications').where('userId', '==', uid).limit(400).get();
  notifs.forEach((n) => batch.delete(n.ref));
  await batch.commit();

  await admin.auth().deleteUser(uid);
  return { success: true, forfeited: balance };
});
