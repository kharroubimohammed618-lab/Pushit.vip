#!/usr/bin/env bash
# One-command deploy of the Pushit Cloud Functions + credit packages (phone friendly).
set -e
PROJECT="gen-lang-client-0155390739"

echo "== 1/6 Installing Firebase tools =="
npm install -g firebase-tools

echo "== 2/6 Login (open the link, sign in with the Google account that owns the project, paste the code) =="
firebase login --no-localhost

echo "== 3/6 Installing function dependencies =="
(cd functions && npm install)

echo "== 4/6 Deploying functions =="
firebase deploy --only functions --project "$PROJECT"

echo "== 5/6 Publishing the new security rules (rollback copy: firestore_rules_quickfix.txt) =="
firebase deploy --only firestore:rules --project "$PROJECT"

echo "== 6/6 Updating the credit packages in the database =="
(cd functions && node ../scripts/apply-pricing.cjs) || echo "NOTE: packages were not updated automatically. Edit them in the Admin Dashboard > Packages."

echo ""
echo "DONE. Check Firebase Console > Functions: the functions must be listed in europe-west1."
