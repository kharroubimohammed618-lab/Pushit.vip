/**
 * Writes the recommended credit packages to Firestore (collection coin_packages).
 * Safe to run more than once. Only the fields listed below are changed (merge).
 *
 *   cd functions
 *   node ../scripts/apply-pricing.cjs --dry-run     # preview
 *   node ../scripts/apply-pricing.cjs               # apply
 *
 * Works in Google Cloud Shell (it already has your Google credentials).
 * If it cannot authenticate, edit the same values in the Admin Dashboard > Packages.
 */
const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

const PROJECT_ID = 'gen-lang-client-0155390739';
const DATABASE_ID = 'ai-studio-pushit-85848e4f-fa77-453b-9f02-aacf84b571c5';
const dryRun = process.argv.includes('--dry-run');

// 1 credit pays a creator USD 0.10. Every pack must sell credits for clearly MORE than that.
const PACKAGES = [
  { id: 'pkg_starter', name: 'Starter Booster (20 Credits)', arName: 'باقة التجربة (20 كوينز)', karmaAmount: 20, bonusKarma: 0, priceUsd: 2.99, whopPlanId: 'plan_XobJA5AxLRNiE', isActive: false, order: 1, badgeText: '1 Verified Clip', arBadgeText: 'كليب موثق واحد' },
  { id: 'pkg_popular', name: 'Creator Pack (50 + 5 BONUS)', arName: 'باقة الصنّاع (50 + 5 بونص)', karmaAmount: 50, bonusKarma: 5, priceUsd: 7.99, whopPlanId: 'plan_vmaDAQ1LrufDU', isActive: true, order: 2, badgeText: '2 Clips OR 1 UGC', arBadgeText: '2 كليب أو 1 UGC' },
  { id: 'pkg_growth', name: 'Growth Pack (100 + 5 BONUS)', arName: 'باقة النمو السريع (100 + 5 بونص)', karmaAmount: 100, bonusKarma: 5, priceUsd: 14.99, whopPlanId: 'plan_Xm9RoYeEYAvKd', isActive: true, order: 3, badgeText: '5 Clips OR 2 UGC', arBadgeText: '5 كليب أو 2 UGC' },
  { id: 'pkg_pro', name: 'Pro Turbo (200 + 15 BONUS)', arName: 'باقة الاحتراف Turbo (200 + 15 بونص)', karmaAmount: 200, bonusKarma: 15, priceUsd: 29.99, whopPlanId: 'plan_OAprN0t0rpn5Q', isActive: true, order: 4, badgeText: '10 Clips OR 5 UGC', arBadgeText: '10 كليب أو 5 UGC' },
  { id: 'pkg_agency', name: 'Agency Whale (450 + 60 BONUS)', arName: 'باقة الوكالات والشركات (450 + 60 بونص)', karmaAmount: 450, bonusKarma: 60, priceUsd: 69.99, whopPlanId: 'plan_1wP4ttXclcHv0', isActive: true, order: 5, badgeText: '25 Clips OR 12 UGC', arBadgeText: '25 كليب أو 12 UGC' },
];

admin.initializeApp({ projectId: PROJECT_ID });
const db = getFirestore(DATABASE_ID);

(async () => {
  for (const p of PACKAGES) {
    const total = p.karmaAmount + p.bonusKarma;
    console.log(`${p.id.padEnd(12)} $${String(p.priceUsd).padEnd(6)} -> ${String(total).padStart(4)} credits  ($${(p.priceUsd / total).toFixed(3)}/credit)  ${p.isActive ? 'on sale' : 'DISABLED'}`);
    if (!dryRun) await db.doc(`coin_packages/${p.id}`).set(p, { merge: true });
  }
  console.log(dryRun ? '\n[dry-run] nothing was written.' : '\nPackages updated.');
})().catch((e) => {
  console.error('\nCould not update the packages automatically:', e.message);
  console.error('Edit the same values in the Admin Dashboard > Packages instead.');
  process.exit(1);
});
