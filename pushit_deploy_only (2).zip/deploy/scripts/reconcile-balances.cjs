/**
 * One-time balance reconciliation (run BEFORE opening the app to users).
 * The new server functions treat  karma = karmaPaid + karmaReward.
 * Old versions of the app sometimes updated only `karma`; this script realigns the 3 fields
 * using `karma` (what users see) as the source of truth.
 *
 *   cd functions
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
 *   node ../scripts/reconcile-balances.cjs --dry-run     # preview only
 *   node ../scripts/reconcile-balances.cjs               # apply
 */
const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

const DATABASE_ID = 'ai-studio-pushit-85848e4f-fa77-453b-9f02-aacf84b571c5';
const dryRun = process.argv.includes('--dry-run');

admin.initializeApp();
const db = getFirestore(DATABASE_ID);

(async () => {
  const snap = await db.collection('usersPrivate').get();
  let fixed = 0;
  for (const d of snap.docs) {
    const u = d.data();
    const total = Math.max(0, Number(u.karma ?? (Number(u.karmaPaid || 0) + Number(u.karmaReward || 0))) || 0);
    const paidRaw = u.karmaPaid !== undefined ? Number(u.karmaPaid) || 0 : total;
    const paid = Math.min(total, Math.max(0, paidRaw));
    const reward = total - paid;
    if (u.karma !== total || u.karmaPaid !== paid || u.karmaReward !== reward) {
      fixed++;
      console.log(`${d.id}: karma ${u.karma} paid ${u.karmaPaid} reward ${u.karmaReward}  ->  ${total} / ${paid} / ${reward}`);
      if (!dryRun) await d.ref.update({ karma: total, karmaPaid: paid, karmaReward: reward });
    }
  }
  console.log(`${dryRun ? '[dry-run] ' : ''}${fixed} of ${snap.size} accounts ${dryRun ? 'would be' : 'were'} realigned.`);
})().catch((e) => { console.error(e); process.exit(1); });
