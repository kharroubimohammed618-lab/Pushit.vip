/**
 * READ-ONLY financial health report. Changes nothing.
 *
 *   cd functions
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
 *   node ../scripts/financial-report.cjs [--fee-percent=3] [--fee-fixed=0.30] [--payout=0.10]
 *
 * Shows: money in (purchases), refunds, money out (payouts), what you still owe creators,
 * and the worst-case liability if every credit in circulation were paid out.
 * The processor-fee numbers are ASSUMPTIONS: pass your real Whop fees as arguments.
 */
const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

const DATABASE_ID = 'ai-studio-pushit-85848e4f-fa77-453b-9f02-aacf84b571c5';
const arg = (name, def) => {
  const a = process.argv.find((x) => x.startsWith(`--${name}=`));
  return a ? Number(a.split('=')[1]) : def;
};
const FEE_PCT = arg('fee-percent', 3);
const FEE_FIXED = arg('fee-fixed', 0.3);
const PAYOUT = arg('payout', 0.1); // USD paid per earned credit
const usd = (n) => `$${(Math.round(n * 100) / 100).toFixed(2)}`;

admin.initializeApp();
const db = getFirestore(DATABASE_ID);

(async () => {
  const [purchases, withdrawals, users] = await Promise.all([
    db.collection('purchases').get(),
    db.collection('withdrawals').get(),
    db.collection('usersPrivate').get(),
  ]);

  let gross = 0, refunded = 0, fees = 0, soldCredits = 0, completed = 0;
  purchases.forEach((d) => {
    const o = d.data();
    if (o.status === 'completed') {
      completed++;
      gross += Number(o.amountUsd || 0);
      soldCredits += Number(o.totalKarma || 0);
      fees += Number(o.amountUsd || 0) * FEE_PCT / 100 + FEE_FIXED;
    }
    if (o.status === 'refunded') refunded += Number(o.amountUsd || 0);
  });

  let paidOut = 0, pending = 0, pendingCount = 0;
  withdrawals.forEach((d) => {
    const w = d.data();
    const value = Number(w.netUsd ?? Number(w.amount || 0) * PAYOUT);
    if (w.status === 'approved') paidOut += value;
    if (w.status === 'pending') { pending += value; pendingCount++; }
  });

  let earned = 0, purchased = 0, debtCredits = 0, held = 0;
  users.forEach((d) => {
    const u = d.data();
    const total = Number(u.karma || 0);
    const paid = Math.min(total, Number(u.karmaPaid ?? total));
    purchased += paid;
    earned += total - paid;
    debtCredits += Number(u.chargebackDebt || 0);
    if (u.payoutHold) held++;
  });

  const cash = gross - refunded - fees - paidOut;
  const owedNow = earned * PAYOUT;                       // creators could withdraw this today
  const worstCase = (earned + purchased) * PAYOUT;       // every credit in circulation ends up paid out

  console.log('\n=== MONEY IN ===');
  console.log(`Completed purchases: ${completed}   gross: ${usd(gross)}   refunded/disputed: ${usd(refunded)}`);
  console.log(`Estimated processor fees (${FEE_PCT}% + ${usd(FEE_FIXED)} per payment, ASSUMPTION): ${usd(fees)}`);
  console.log('\n=== MONEY OUT ===');
  console.log(`Payouts approved: ${usd(paidOut)}   pending requests: ${usd(pending)} (${pendingCount})`);
  console.log('\n=== POSITION ===');
  console.log(`Cash kept so far (in - refunds - fees - payouts): ${usd(cash)}`);
  console.log(`Owed to creators today (earned credits x ${PAYOUT}): ${usd(owedNow)}`);
  console.log(`Worst case if ALL credits in circulation were paid out: ${usd(worstCase)}`);
  console.log(`Profit if you had to settle everything today: ${usd(cash - owedNow)}   |   worst case: ${usd(cash - worstCase)}`);
  console.log('\n=== RISK FLAGS ===');
  console.log(`Credits sold: ${soldCredits}   avg sale price per credit: ${soldCredits ? usd(gross / soldCredits) : 'n/a'} (payout value per credit: ${usd(PAYOUT)})`);
  if (soldCredits && gross / soldCredits < PAYOUT) console.log('!! You sell credits for LESS than you pay creators for them: every campaign built on these credits loses money.');
  console.log(`Accounts with chargeback debt: ${debtCredits} credits, accounts on payout hold: ${held}`);
})().catch((e) => { console.error(e); process.exit(1); });
